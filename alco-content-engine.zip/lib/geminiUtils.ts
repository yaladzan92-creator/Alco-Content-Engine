export function extractJSON(text: string): any {
  if (!text) return {};
  
  // Try direct parse first
  try {
    return JSON.parse(text.trim());
  } catch (_) {
    // try to find JSON block in markdown
    try {
      const match = text.match(/```(?:json)?([\s\S]*?)```/);
      if (match && match[1]) {
        return JSON.parse(match[1].trim());
      }
    } catch (e) {
      console.error("Failed to parse markdown JSON matches", e);
    }
  }

  // Last-ditch effort: find first active { and match with last }
  try {
    const firstBrace = text.indexOf("{");
    const lastBrace = text.lastIndexOf("}");
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      const jsonCandidate = text.substring(firstBrace, lastBrace + 1);
      return JSON.parse(jsonCandidate);
    }
  } catch (e) {
    console.error("Failed first-to-last brace extraction", e);
  }

  throw new Error("Could not find parsable JSON in model output");
}
