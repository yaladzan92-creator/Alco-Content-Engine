export function trackActivity(name: string, description: string) {
  console.log(`[Activity Tracked] ${name}: ${description}`);
  if (typeof window !== "undefined") {
    const historical = localStorage.getItem("alco_activity_log") || "[]";
    try {
      const logs = JSON.parse(historical);
      logs.unshift({ id: Date.now(), name, description, timestamp: new Date().toISOString() });
      localStorage.setItem("alco_activity_log", JSON.stringify(logs.slice(0, 100)));
    } catch (e) {
      // ignore
    }
  }
}
