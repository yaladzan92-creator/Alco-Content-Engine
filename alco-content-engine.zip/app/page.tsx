"use client";

import React, { useState, useEffect } from "react";
import { 
  Building2, 
  Sparkles, 
  Calendar, 
  BookOpen, 
  User, 
  Target, 
  Layers, 
  FilePlay, 
  CheckCircle, 
  Plus, 
  Trash2, 
  Save, 
  ArrowRight, 
  RefreshCcw, 
  Copy, 
  ExternalLink, 
  ListChecks, 
  Filter, 
  HelpCircle, 
  Activity, 
  Sparkle,
  Sliders,
  Send,
  X,
  PlusCircle,
  FileText,
  BadgeCheck,
  Megaphone,
  Check,
  Radio,
  Wifi,
  WifiOff,
  FileJson,
  Key,
  Globe,
  ShieldAlert,
  Cpu,
  Terminal,
  Database,
  ChevronRight
} from "lucide-react";
import Link from "next/link";
import { motion, AnimatePresence } from "motion/react";
import { CalendarView } from "../CalendarView";
import { extractJSON } from "../lib/geminiUtils";

// Types
interface BrandContextType {
  brandName: string;
  brandIdentity: {
    voice: string;
    tone: string;
    mission: string;
    values: string[];
  };
  audience: {
    segments: string[];
    painPoints: string[];
    desires: string[];
  };
  positioning: {
    corePromise: string;
    tagline: string;
    differentiation: string[];
  };
  offers: {
    name: string;
    benefits: string[];
    price: string;
    ctaText: string;
  }[];
  messaging: {
    keyPillars: string[];
    elevatorPitch: string;
    conversationalHooks: string[];
  };
  contentStrategy: {
    pillars: string[];
    preferredChannels: string[];
    angles: string[];
  };
  brandRules: {
    doRules: string[];
    dontRules: string[];
  };
}

interface ContentItem {
  no: number;
  tanggal: string;
  jenis: string;
  tujuan: string;
  hookType: string;
  headline: string;
  body: string;
  caption: string;
  format: string;
  referensi: string;
  visual: string;
  keterangan: string;
}

interface CalendarItem {
  id: string; // Unique ID so we can edit/delete/duplicate easily
  dayIndex: number;
  funnelStage: "TOFU" | "MOFU" | "BOFU";
  contentObjective: string;
  contentFormat: "Single Image" | "Carousel" | "Reel";
  topic: string;
  hook: string;
  cta: string;
  // If detail has been generated for this item, store here
  isInflated?: boolean;
  inflatedDetails?: DailyDetails;
}

interface DailyDetails {
  contentObjective: string;
  hook: string;
  mainMessage: string;
  caption: string;
  cta: string;
  visualDirection: string;
  designBrief: string;
  imagePrompt: string;
}

interface LibraryItem {
  id: string;
  calendarItem: Omit<CalendarItem, 'inflatedDetails' | 'isInflated'>;
  details: DailyDetails;
  brandName: string;
  status: "Draft" | "Approved" | "Scheduled" | "Published";
  createdDate: string;
}

interface DynamicBrand {
  id: string;
  name: string;
  desc: string;
}

interface DynamicProject {
  id: string;
  name: string;
  workspace: string;
}

const PRESET_WORKSPACES = [
  "Sandbox Workspace"
];

const PRESET_PROJECTS = [
  "Sandbox Campaign Blueprint"
];

const PRESET_BRANDS = [
  { id: "custom", name: "+ Custom Brand Intelligence", desc: "Define/import custom strategy inputs dynamically" }
];

interface ApiDiagnostics {
  apiUrl: string;
  healthUrl: string;
  status: string | number | null;
  responseBody: string | null;
  timestamp: string | null;
}

const getCleanBaseUrl = (inputUrl: string) => {
  let clean = inputUrl.trim();
  
  // Strip trailing slashes
  clean = clean.replace(/\/+$/, "");
  
  // Prevent duplicate suffixes
  if (clean.endsWith("/api/health")) {
    clean = clean.substring(0, clean.length - 11).replace(/\/+$/, "");
  } else if (clean.endsWith("/api")) {
    clean = clean.substring(0, clean.length - 4).replace(/\/+$/, "");
  } else if (clean.endsWith("/health")) {
    clean = clean.substring(0, clean.length - 7).replace(/\/+$/, "");
  }
  
  return clean;
};

export default function App2ContentEngine() {
  // Navigation tabs for the dual views: Campaign Architect & Saved Library
  const [activeViewTab, setActiveViewTab] = useState<"architect" | "library">("architect");

  // MODULE 0 - API CONNECTION CENTER state
  const [apiBaseUrl, setApiBaseUrl] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return window.localStorage.getItem("alco_api_url") || "";
    }
    return "";
  });
  const [apiToken, setApiToken] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return window.localStorage.getItem("alco_api_key") || "";
    }
    return "";
  });
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "testing" | "active" | "failed">("disconnected");
  const [lastSync, setLastSync] = useState<string>("Never");
  const [schemaVersion, setSchemaVersion] = useState("v2.1.0");
  const [detectedWorkspacesCount, setDetectedWorkspacesCount] = useState(0);
  const [detectedBrandsCount, setDetectedBrandsCount] = useState(0);
  const [detectedProjectsCount, setDetectedProjectsCount] = useState(0);
  const [fallbackModeActive, setFallbackModeActive] = useState(false);
  const [jsonImportError, setJsonImportError] = useState<string | null>(null);
  const [pasteJsonText, setPasteJsonText] = useState("");
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [isConnectionCenterCollapsed, setIsConnectionCenterCollapsed] = useState(false);
  const [apiDiagnostics, setApiDiagnostics] = useState<ApiDiagnostics | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [dynamicBrands, setDynamicBrands] = useState<DynamicBrand[]>([]);
  const [dynamicProjects, setDynamicProjects] = useState<DynamicProject[]>([]);

  // STEP 1 State
  const [selectedWorkspace, setSelectedWorkspace] = useState("Sandbox Workspace");
  const [selectedProject, setSelectedProject] = useState("Sandbox Campaign Blueprint");
  const [selectedBrandId, setSelectedBrandId] = useState("custom");

  // Custom Brand input variables (Applies only if selectedBrandId === "custom")
  const [customBrandName, setCustomBrandName] = useState("Aura Glow Skincare");
  const [customVoice, setCustomVoice] = useState("Sahabat akrab & solutif");
  const [customTone, setCustomTone] = useState("Sopan, hangat, mudah dipahami, dan ramah");
  const [customCorePromise, setCustomCorePromise] = useState("Wajah glowing alami bebas kusam dalam 14 hari dengan bahan herbal 100% organik.");
  const [customAudience, setCustomAudience] = useState("Wanita muda usia 18-35 tahun yang ingin merawat kulit wajah sehat bebas kimia berbahaya");
  const [customOfferName, setCustomOfferName] = useState("Paket Aura Glow Ultimate");
  const [customOfferPrice, setCustomOfferPrice] = useState("Rp 195.000 (Potongan 20%)");
  const [customRules, setCustomRules] = useState("Gunakan bahasa santai yang akrab. Selalu sertakan tips perawatan kulit sederhana. Hindari istilah kimia yang terlalu rumit.");

  // STEP 2 & 3 State: The Content Context
  const [brandContext, setBrandContext] = useState<BrandContextType | null>(null);
  const [isLoadingContext, setIsLoadingContext] = useState(false);
  const [notification, setNotification] = useState<{message: string; type: "success" | "error" | "info"} | null>(null);

  // Dialog / Edit states for Context Details (Edit inline on Step 3)
  const [editableContext, setEditableContext] = useState<BrandContextType | null>(null);
  const [editingFieldType, setEditingFieldType] = useState<string | null>(null);
  const [tempInputValue, setTempInputValue] = useState("");

  // STEP 4 State: Campaign Goals
  const [campaignDuration, setCampaignDuration] = useState("14"); // "7" | "14" | "30" | "custom"
  const [customDurationDays, setCustomDurationDays] = useState(5);
  const [campaignObjective, setCampaignObjective] = useState<"Brand Awareness" | "Engagement" | "Lead Generation" | "Sales">("Engagement");

  // STEP 5 & 6 State: Generated Calendar review
  const [generatedCalendar, setGeneratedCalendar] = useState<CalendarItem[]>([]);
  const [isGeneratingCalendar, setIsGeneratingCalendar] = useState(false);
  const [selectedCalendarItemId, setSelectedCalendarItemId] = useState<string | null>(null);
  const [editingCalendarItem, setEditingCalendarItem] = useState<CalendarItem | null>(null);

  // STEP 7 State: Daily content generation
  const [isGeneratingDaily, setIsGeneratingDaily] = useState(false);
  const [activeDailyDetails, setActiveDailyDetails] = useState<DailyDetails | null>(null);

  // Pure dynamic counter to avoid Date.now in render/state scopes
  const [idCounter, setIdCounter] = useState(100);

  // CalendarView state variables
  const [calendarItems, setCalendarItems] = useState<ContentItem[]>([]);
  const [growthCalendarItems, setGrowthCalendarItems] = useState<ContentItem[]>([]);
  const [isConfiguringCalendar, setIsConfiguringCalendar] = useState(false);
  const [currentStepCalendar, setCurrentStepCalendar] = useState(0);
  const [activeConfigCellCalendar, setActiveConfigCellCalendar] = useState<number | null>(null);
  const [revisionsCalendar, setRevisionsCalendar] = useState<Record<number, string>>({});
  const [accessCode, setAccessCode] = useState("alco_elite_pass_2026");
  const [isAccessValid, setIsAccessValid] = useState(true);
  const [isEditAccessLocked, setIsEditAccessLocked] = useState(false);
  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [filterTypeCalendar, setFilterTypeCalendar] = useState("All");
  const [calendarHistory, setCalendarHistory] = useState<any[]>([]);

  // configData variables for the Step-by-Step wizard
  const [calCoreTopic, setCalCoreTopic] = useState("ScaleFlow Operations Ignite");
  const [calStartDate, setCalStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [calCampaignDuration, setCalCampaignDuration] = useState("14");
  const [calFormats, setCalFormats] = useState<string[]>(["Single", "Carousel"]);
  const [calCarouselSlides, setCalCarouselSlides] = useState(5);
  const [calReelsDuration, setCalReelsDuration] = useState("30s");
  const [calRatio, setCalRatio] = useState({ tofu: 6, mofu: 5, bofu: 3 });
  const [calFormatRatio, setCalFormatRatio] = useState({ Single: 60, Carousel: 40, Reels: 0 });
  const [calSelectedVoices, setCalSelectedVoices] = useState<string[]>(["Professional", "Empathetic"]);
  const [calHookMix, setCalHookMix] = useState([
    { type: "Benefit-driven", percentage: 50 },
    { type: "Pain-point callout", percentage: 30 },
    { type: "Story-telling", percentage: 20 }
  ]);
  const [calReferenceType, setCalReferenceType] = useState("LinkedIn");
  const [calSelectedCTAs, setCalSelectedCTAs] = useState<string[]>(["Start Pro Trial", "Claim Scale Audit"]);
  const [calSelectedFormula, setCalSelectedFormula] = useState("AIDA (Attention, Interest, Desire, Action)");
  const [calIsFastMode, setCalIsFastMode] = useState(false);
  const [calGender, setCalGender] = useState("Both");
  const [calAgeRange, setCalAgeRange] = useState<[number, number]>([20, 50]);
  const [calSkipDays, setCalSkipDays] = useState<string[]>([]);

  // STEP 8 State: Saved Library Store (Backed by localStorage)
  const [savedLibrary, setSavedLibrary] = useState<LibraryItem[]>(() => {
    if (typeof window !== "undefined") {
      const local = window.localStorage.getItem("alco_content_library_db");
      if (local) {
        try {
          return JSON.parse(local);
        } catch (e) {
          console.error("Failed to parse local content library db", e);
        }
      }
    }
    return [];
  });
  const [libraryFilterStatus, setLibraryFilterStatus] = useState<string>("All");
  const [expandedLibraryItemId, setExpandedLibraryItemId] = useState<string | null>(null);
  const [copiedTextState, setCopiedTextState] = useState<string | null>(null);


  const triggerNotification = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  const fetchSelectedBrandContext = async (brandId: string, url: string, key: string) => {
    setIsLoadingContext(true);
    try {
      const baseDomain = getCleanBaseUrl(url);
      const finalApiUrl = baseDomain === "" ? "/api" : `${baseDomain}/api`;
      const contextUrl = `${finalApiUrl}/context/content/${brandId}`;
      const requestHeaders = {
        "x-api-key": key,
        "Content-Type": "application/json"
      };
      console.log("Raw API URL:", url);
      console.log("Final API URL:", finalApiUrl);
      console.log("API URL:", contextUrl);
      console.log("API Key:", key?.substring(0, 8));
      console.log("Headers:", requestHeaders);

      const res = await fetch(contextUrl, {
        headers: requestHeaders
      });

      if (!res.ok) {
        throw new Error(`Failed to load context folder contents (${res.status})`);
      }

      const data = await res.json();
      setBrandContext(data);
      setEditableContext(JSON.parse(JSON.stringify(data)));
      triggerNotification(`Berhasil mengambil info data Brand: ${data.brandName}`);
    } catch (e: any) {
      console.error(e);
      triggerNotification(`Gagal memuat data Brand: ${e.message}`, "error");
    } finally {
      setIsLoadingContext(false);
    }
  };

  // Perform secure, structured health check and sync remote brand dossiers
  const executeActualHealthCheck = async (url: string, key: string, isRetry: boolean = false) => {
    setIsConnecting(true);
    setConnectionStatus("testing");
    setConnectionError(null);
    setApiDiagnostics(null);
    triggerNotification("Sedang memeriksa koneksi server...", "info");

    const baseDomain = getCleanBaseUrl(url);
    const finalApiUrl = baseDomain === "" ? "/api" : `${baseDomain}/api`;
    const healthUrl = `${finalApiUrl}/health`;

    // 4. Logging before fetch (Requirement 4)
    console.log("Raw API URL:", url);
    console.log("Final Health URL:", healthUrl);

    // 5. If healthUrl is relative, report the cause (Requirement 5)
    if (healthUrl === "/api/health") {
      console.warn("[API CONNECTION CHECK]: healthUrl is relative '/api/health'. This fallback occurs because the input API URL was empty or resolved to root; wait for manual connection center entry or local preview initialization in /app/page.tsx.");
    }

    try {
      const requestHeaders = {
        "x-api-key": key,
        "Content-Type": "application/json"
      };

      console.log("API URL:", healthUrl);
      console.log("API Key:", key?.substring(0, 8));
      console.log("Headers:", requestHeaders);

      const res = await fetch(healthUrl, {
        method: "GET",
        headers: requestHeaders
      });

      const text = await res.text();
      let parsedBody: any = null;
      try {
        parsedBody = JSON.parse(text);
      } catch (_) {
        parsedBody = text || "(Empty string)";
      }

      console.log("Final API URL:", finalApiUrl);
      console.log("Final Health URL:", healthUrl);
      console.log("Response Status:", res.status);
      console.log("Response Body:", text);

      const fetchedDiagnostics: ApiDiagnostics = {
        apiUrl: finalApiUrl,
        healthUrl: healthUrl,
        status: res.status,
        responseBody: typeof parsedBody === "object" ? JSON.stringify(parsedBody, null, 2) : String(parsedBody),
        timestamp: new Date().toLocaleTimeString("id-ID")
      };

      setApiDiagnostics(fetchedDiagnostics);

      if (!res.ok) {
        throw new Error(`Failed to connect. URL: ${healthUrl} Status: ${res.status}`);
      }

      if (typeof parsedBody === "string" && parsedBody.includes("<!DOCTYPE html>")) {
        throw new Error(`Endpoint returned HTML instead of JSON metadata.`);
      }

      const verifiedApiBase = finalApiUrl;
      const verifiedToken = key;

      // Load brands & projects
      const brandsUrl = `${verifiedApiBase}/brands`;
      const projectsUrl = `${verifiedApiBase}/projects`;

      const requestHeadersSync = {
        "x-api-key": verifiedToken,
        "Content-Type": "application/json"
      };

      console.log("API URL:", brandsUrl);
      console.log("API Key:", verifiedToken?.substring(0, 8));
      console.log("Headers:", requestHeadersSync);

      console.log("API URL:", projectsUrl);
      console.log("API Key:", verifiedToken?.substring(0, 8));
      console.log("Headers:", requestHeadersSync);

      const [brandsRes, projectsRes] = await Promise.all([
        fetch(brandsUrl, { headers: requestHeadersSync }),
        fetch(projectsUrl, { headers: requestHeadersSync })
      ]);

      if (!brandsRes.ok) throw new Error(`Brands endpoint failed (${brandsRes.status})`);
      if (!projectsRes.ok) throw new Error(`Projects endpoint failed (${projectsRes.status})`);

      const brandsData = await brandsRes.json();
      const projectsData = await projectsRes.json();

      // Update state with dynamic results
      setDynamicBrands(brandsData);
      setDynamicProjects(projectsData);
      
      // Save credentials.
      localStorage.setItem("alco_api_url", verifiedApiBase);
      localStorage.setItem("alco_api_key", verifiedToken);

      setApiBaseUrl(verifiedApiBase);
      setApiToken(verifiedToken);
      setConnectionStatus("active");
      setLastSync(new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      setDetectedWorkspacesCount(projectsData.length);
      setDetectedBrandsCount(brandsData.length);
      setDetectedProjectsCount(projectsData.length);
      setFallbackModeActive(false);

      triggerNotification("Koneksi berhasil terhubung dan tersambung dengan database!");

      // If brands are found, automatically pre-select and trigger GET /api/context/content/{brandId}
      if (brandsData.length > 0) {
        const firstBrand = brandsData[0];
        setSelectedBrandId(firstBrand.id);
        fetchSelectedBrandContext(firstBrand.id, verifiedApiBase, verifiedToken);
      }
      if (projectsData.length > 0) {
        setSelectedProject(projectsData[0].name);
        setSelectedWorkspace(projectsData[0].workspace || "ALCO Enterprise Hub");
      }
      setIsConnecting(false);
    } catch (err: any) {
      console.error("API link failed:", err);

      setConnectionStatus("failed");
      setConnectionError(err.message || "Network Error / Host Offline. Please verify details or check CORS.");
      setDetectedWorkspacesCount(0);
      setDetectedBrandsCount(0);
      setDetectedProjectsCount(0);
      
      // Update diagnostics on error to display the precise trace details for users (Requirement 5)
      setApiDiagnostics({
        apiUrl: finalApiUrl,
        healthUrl: healthUrl,
        status: err.message?.includes("Status: ") ? err.message.split("Status: ")[1] : "Fail / Offline",
        responseBody: err.message || "Network connection failure",
        timestamp: new Date().toLocaleTimeString("id-ID")
      });

      triggerNotification(`Koneksi API Gagal: ${err.message || "Masalah sambungan jaringan"}`, "error");
      setIsConnecting(false);
    }
  };

  // On Mount: Auto sync with saved credentials if they exist in localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedUrl = window.localStorage.getItem("alco_api_url");
      const savedKey = window.localStorage.getItem("alco_api_key");
      const savedFallback = window.localStorage.getItem("alco_fallback_mode_active") === "true";
      const savedDossierJson = window.localStorage.getItem("alco_imported_dossier");

      if (savedFallback) {
        setTimeout(() => {
          setFallbackModeActive(true);
          setConnectionStatus("disconnected");
          setSelectedBrandId("custom");
          
          if (savedDossierJson) {
            try {
              const parsed = JSON.parse(savedDossierJson);
              setBrandContext(parsed);
              setEditableContext(JSON.parse(JSON.stringify(parsed)));
              // Hydrate inputs
              setCustomBrandName(parsed.brandName || "My Brand");
              if (parsed.brandIdentity?.voice) setCustomVoice(parsed.brandIdentity.voice);
              if (parsed.brandIdentity?.tone) setCustomTone(parsed.brandIdentity.tone);
              if (parsed.positioning?.corePromise) setCustomCorePromise(parsed.positioning.corePromise);
              if (parsed.audience?.segments?.[0]) setCustomAudience(parsed.audience.segments[0]);
              if (parsed.offers?.[0]?.name) setCustomOfferName(parsed.offers[0].name);
              if (parsed.offers?.[0]?.price) setCustomOfferPrice(parsed.offers[0].price);
              if (parsed.brandRules?.doRules) setCustomRules(parsed.brandRules.doRules.join(". "));
            } catch (e) {
              console.error("Failed to parse saved dossier", e);
            }
          }
        }, 0);
      } else if (savedUrl && savedKey) {
        setTimeout(() => {
          executeActualHealthCheck(savedUrl, savedKey);
        }, 0);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // CalendarView state handlers and auto-fill sync effect
  const handleCalendarReschedule = (itemNo: number, newDate: string) => {
    setCalendarItems(prev => prev.map(item => {
      if (item.no === itemNo) {
        return { ...item, tanggal: newDate };
      }
      return item;
    }));
    triggerNotification(`Jadwal Konten #${itemNo} dipindahkan ke ${newDate}`, "info");
  };

  const handleCalendarUpdateItem = (updated: ContentItem) => {
    setCalendarItems(prev => prev.map(item => {
      if (item.no === updated.no) {
        return updated;
      }
      return item;
    }));
    triggerNotification(`Detail Konten #${updated.no} Berhasil Disimpan!`, "success");
  };

  const handleCalendarRegenerateItem = async (itemNo: number, instruction: string) => {
    triggerNotification(`Kecerdasan Buatan (AI) sedang mengubah konten #${itemNo}...`, "info");
    try {
      const active = calendarItems.find(item => item.no === itemNo);
      if (!active) return;

      const res = await fetch("/api/gemini/recommendation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Sempurnakan konten berikut berdasarkan instruksi: "${instruction}".
          Konten lama:
          Headline: ${active.headline}
          Body: ${active.body}
          Keterangan CTA: ${active.keterangan}
          Format: ${active.format}
          
          Kembalikan hasil dalam format JSON yang valid dengan properti:
          {"headline": "Headline baru", "body": "Copy body/artikel baru", "keterangan": "CTA Baru"}`
        })
      });

      if (!res.ok) throw new Error("Tweak AI failed.");
      const resData = await res.json();
      const parsed = extractJSON(resData.text || "{}");

      setCalendarItems(prev => prev.map(item => {
        if (item.no === itemNo) {
          return {
            ...item,
            headline: parsed.headline || item.headline,
            body: parsed.body || item.body,
            keterangan: parsed.keterangan || item.keterangan
          };
        }
        return item;
      }));

      triggerNotification(`Perubahan konten #${itemNo} berhasil diterapkan! ✨`, "success");
    } catch (e: any) {
      console.error(e);
      triggerNotification("Gagal mengubah konten.", "error");
    }
  };

  const handleGenerateStrategyFromCalendarView = async () => {
    setIsGeneratingCalendar(true);
    triggerNotification("Sedang merancang kampanye promosi multi-tahap dengan AI...", "info");

    try {
      const actualDays = parseInt(calCampaignDuration) || 14;
      const res = await fetch("/api/gemini/calendar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          brandContext: editableContext || {
            brandName: "ALCO",
            brandIdentity: { voice: "Expert", tone: "Professional", mission: "Scale operations", values: [] },
            audience: { segments: ["Founders"], painPoints: [], desires: [] },
            positioning: { corePromise: "", tagline: "", differentiation: [] },
            offers: [],
            messaging: { keyPillars: [], elevatorPitch: "", conversationalHooks: [] },
            contentStrategy: { pillars: [], preferredChannels: [], angles: [] },
            brandRules: { doRules: [], dontRules: [] }
          },
          durationDays: actualDays,
          objective: campaignObjective,
          coreTopic: calCoreTopic,
          voice: calSelectedVoices.join(", "),
          formula: calSelectedFormula
        })
      });

      if (!res.ok) throw new Error("Gemini API failed to generate schema.");
      const data = await res.json();
      
      if (data.error) throw new Error(data.error);

      const rawCalendar: any[] = data.calendar || [];
      const updatedItems = rawCalendar.map((item, i) => {
        const itemDate = new Date(calStartDate);
        itemDate.setDate(itemDate.getDate() + i);
        const dateStr = itemDate.toISOString().split("T")[0];

        return {
          no: i + 1,
          tanggal: dateStr,
          jenis: item.funnelStage || "TOFU",
          tujuan: item.contentObjective || campaignObjective,
          hookType: item.hook || "rhythmic callout",
          headline: item.topic || "Optimized Operational Lever",
          body: item.inflatedDetails?.body || `Topic focus: ${item.topic}. Call to Action: ${item.cta}`,
          caption: item.inflatedDetails?.body || "",
          format: item.contentFormat || "Single Image",
          referensi: item.funnelStage || "TOFU",
          visual: item.inflatedDetails?.visualPrompt || `Crisp branding element highlighting ${item.topic}`,
          keterangan: item.cta || "Check link in bio"
        };
      });

      setCalendarItems(updatedItems);
      
      const mappedBack: CalendarItem[] = rawCalendar.map((item, i) => ({
        id: `cal-item-gen-${idCounter}-${i}`,
        dayIndex: i + 1,
        funnelStage: item.funnelStage || "TOFU",
        contentObjective: item.contentObjective || campaignObjective,
        contentFormat: item.contentFormat || "Single Image",
        topic: item.topic || "Active Operations",
        hook: item.hook || "rhythmic hook",
        cta: item.cta || "Check out free audit"
      }));

      setIdCounter(prev => prev + 1);
      setGeneratedCalendar(mappedBack);
      setIsConfiguringCalendar(false);
      triggerNotification(`Berhasil membuat ${updatedItems.length} rencana konten promosi! ✨`, "success");
    } catch (e: any) {
      console.error(e);
      triggerNotification(e.message || "Gagal membuat rencana konten promosi.", "error");
    } finally {
      setIsGeneratingCalendar(false);
    }
  };

  // Synchronize dynamic calendar values automatically from chosen API project
  useEffect(() => {
    if (connectionStatus === "active" && editableContext) {
      const brandName = editableContext.brandName || "Active Brand";
      const projectTopic = selectedProject ? `${brandName}: ${selectedProject}` : `${brandName} Launch Strategy`;

      const timer = setTimeout(() => {
        setCalCoreTopic(projectTopic);

        if (editableContext.brandIdentity?.voice) {
          setCalSelectedVoices([editableContext.brandIdentity.voice]);
        }

        if (editableContext.offers && editableContext.offers.length > 0) {
          const offerCTAs = editableContext.offers.map((o: any) => o.ctaText).filter(Boolean);
          if (offerCTAs.length > 0) {
            setCalSelectedCTAs(offerCTAs);
          }
        }

        const contentPillars = editableContext.contentStrategy?.pillars || [];
        const displayTopic = `${selectedProject || "Campaign"} - Focus: ${contentPillars[0] || brandName}`;
        setCalCoreTopic(displayTopic);
      }, 0);

      return () => clearTimeout(timer);
    }
  }, [selectedProject, brandContext, connectionStatus, editableContext]);

  const handlePasteChange = (text: string) => {
    setPasteJsonText(text);
    try {
      const trimmed = text.trim();
      if (trimmed.startsWith("{")) {
        const parsed = JSON.parse(trimmed);
        if (parsed.apiUrl || parsed.apiBaseUrl) {
          setApiBaseUrl(parsed.apiUrl || parsed.apiBaseUrl);
        }
        if (parsed.apiKey || parsed.apiToken) {
          setApiToken(parsed.apiKey || parsed.apiToken);
        }
      } else {
        const urlMatch = trimmed.match(/(?:apiUrl|url)["'\s:=]+([^;"'\s]+)/i);
        const keyMatch = trimmed.match(/(?:apiKey|key|token)["'\s:=]+([^;"'\s]+)/i);
        if (urlMatch) setApiBaseUrl(urlMatch[1]);
        if (keyMatch) setApiToken(keyMatch[1]);
      }
    } catch (_) {
      // Allow typing without throwing syntax alert
    }
  };

  const handleManualConnect = () => {
    if (!apiBaseUrl.trim() || !apiToken.trim()) {
      triggerNotification("Peringatan: Alamat API dan Kunci Token wajib diisi.", "error");
      return;
    }
    executeActualHealthCheck(apiBaseUrl, apiToken);
  };

  const testApiConnection = async (simulateFailure: boolean = false) => {
    if (simulateFailure) {
      setConnectionStatus("failed");
      setConnectionError("Simulated API Connection breakdown. Gateway forced timeout.");
      triggerNotification("Koneksi API Gagal: Simulasi kerusakan diagnostik.", "error");
      return;
    }
    executeActualHealthCheck(apiBaseUrl, apiToken);
  };



  const handleImportJson = (jsonString: string) => {
    try {
      setJsonImportError(null);
      const parsed = JSON.parse(jsonString);
      
      // Precise metadata validation checks
      if (!parsed.brandName) {
        throw new Error("Missing required field: 'brandName'");
      }
      if (!parsed.brandIdentity || !parsed.brandIdentity.voice || !parsed.brandIdentity.tone) {
        throw new Error("Missing or incomplete 'brandIdentity' (voice and tone needed)");
      }
      if (!parsed.audience || !Array.isArray(parsed.audience.segments)) {
        throw new Error("Missing or invalid 'audience.segments' array");
      }
      if (!parsed.positioning || !parsed.positioning.corePromise) {
        throw new Error("Missing Positioning information");
      }

      const validatedContext: BrandContextType = {
        brandName: parsed.brandName,
        brandIdentity: {
          voice: parsed.brandIdentity.voice || "Professional",
          tone: parsed.brandIdentity.tone || "Direct, honest",
          mission: parsed.brandIdentity.mission || "Simplify workflows.",
          values: parsed.brandIdentity.values || ["Value"]
        },
        audience: {
          segments: parsed.audience.segments || [],
          painPoints: parsed.audience.painPoints || [],
          desires: parsed.audience.desires || []
        },
        positioning: {
          corePromise: parsed.positioning.corePromise || "Optimize tasks.",
          tagline: parsed.positioning.tagline || "Move Fast.",
          differentiation: parsed.positioning.differentiation || []
        },
        offers: parsed.offers || [],
        messaging: parsed.messaging || { keyPillars: [], elevatorPitch: "", conversationalHooks: [] },
        contentStrategy: parsed.contentStrategy || { pillars: [], preferredChannels: [], angles: [] },
        brandRules: parsed.brandRules || { doRules: [], dontRules: [] }
      };

      setBrandContext(validatedContext);
      setEditableContext(JSON.parse(JSON.stringify(validatedContext)));
      setSelectedBrandId("custom");
      
      // Feed custom editor inputs directly so manual settings are hydrated smoothly
      setCustomBrandName(validatedContext.brandName);
      setCustomVoice(validatedContext.brandIdentity.voice);
      setCustomTone(validatedContext.brandIdentity.tone);
      setCustomCorePromise(validatedContext.positioning.corePromise);
      setCustomAudience(validatedContext.audience.segments[0] || "");
      setCustomOfferName(validatedContext.offers[0]?.name || "Imported Package Deal");
      setCustomOfferPrice(validatedContext.offers[0]?.price || "On Demand");
      setCustomRules(validatedContext.brandRules.doRules.join(". "));

      setFallbackModeActive(true);
      setConnectionStatus("disconnected");
      triggerNotification("Berkas data Brand berhasil diimpor!", "success");
    } catch (err: any) {
      console.error(err);
      setJsonImportError(`Gagal memuat: ${err.message || "kesalahan format berkas"}`);
      triggerNotification("Format file JSON belum sesuai dengan data Brand.", "error");
    }
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    setJsonImportError(null);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type !== "application/json" && !file.name.endsWith(".json")) {
        setJsonImportError("Unsupported file type. Please upload a .json config file.");
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        handleImportJson(text);
      };
      reader.onerror = () => {
        setJsonImportError("Could not parse file bytes.");
      };
      reader.readAsText(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setJsonImportError(null);
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        handleImportJson(text);
      };
      reader.onerror = () => {
        setJsonImportError("Could not read chosen dossier file.");
      };
      reader.readAsText(file);
    }
  };

  const loadBrandContext = async () => {
    // Yield execution to the microtask queue to prevent synchronous state triggers inside effects
    await new Promise((resolve) => setTimeout(resolve, 0));

    if (connectionStatus !== "active" && !fallbackModeActive) {
      // Core sync is not active and fallback is not toggled, prevent background loading
      return;
    }

    if (selectedBrandId === "custom") {
      // Build dynamic brand context object out of user typed options
      const dynamicContext: BrandContextType = {
        brandName: customBrandName,
        brandIdentity: {
          voice: customVoice,
          tone: customTone,
          mission: `Empower clients to bypass friction through strategic assets.`,
          values: ["Speed", "Metric-Backed Clarity", "Authentic Value"]
        },
        audience: {
          segments: [customAudience],
          painPoints: ["Losing focus to operational spreadsheets", "Inefficient message delivery"],
          desires: ["Clean growth automations"]
        },
        positioning: {
          corePromise: customCorePromise,
          tagline: "Move Fast. Save Time.",
          differentiation: ["Engineered primarily for boutique agencies", "Instant asset integration"]
        },
        offers: [
          {
            name: customOfferName,
            benefits: ["Strategic workflow design", "1-on1 review session"],
            price: customOfferPrice,
            ctaText: "Get Access Now"
          }
        ],
        messaging: {
          keyPillars: ["Systems multiply focus.", "Frictionless delivery beats raw effort."],
          elevatorPitch: `We specialize in generating brand-aware solutions for high-leverage teams.`,
          conversationalHooks: ["Are your tools working for you, or is it the other way around?"]
        },
        contentStrategy: {
          pillars: ["Systematic Leverage", "Creative Momentum"],
          preferredChannels: ["LinkedIn", "Twitter/X"],
          angles: ["Direct comparison guides showing actual hours saved."]
        },
        brandRules: {
          doRules: customRules.split(".").map(s => s.trim()).filter(Boolean),
          dontRules: ["Avoid dramatic hype, clickbaits, and unbacked promises."]
        }
      };
      setBrandContext(dynamicContext);
      setEditableContext(JSON.parse(JSON.stringify(dynamicContext)));
      triggerNotification("Data Brand kustom berhasil dimuat secara lokal!", "info");
      return;
    }

    setIsLoadingContext(true);
    try {
      const baseDomain = getCleanBaseUrl(apiBaseUrl);
      const finalApiUrl = baseDomain === "" ? "/api" : `${baseDomain}/api`;
      const contextUrl = `${finalApiUrl}/context/content/${selectedBrandId}`;
      const requestHeaders = {
        "x-api-key": apiToken,
        "Content-Type": "application/json"
      };
      console.log("Raw API URL:", apiBaseUrl);
      console.log("Final API URL:", finalApiUrl);
      console.log("API URL:", contextUrl);
      console.log("API Key:", apiToken?.substring(0, 8));
      console.log("Headers:", requestHeaders);

      const res = await fetch(contextUrl, {
        headers: requestHeaders
      });
      if (!res.ok) throw new Error("Could not sync with App 1 Intelligence core API.");
      const data = await res.json();
      setBrandContext(data);
      setEditableContext(JSON.parse(JSON.stringify(data))); // Mutable context copy
      triggerNotification(`Berhasil sinkronisasi info Brand dengan server API untuk ${data.brandName}`);
    } catch (e: any) {
      console.error(e);
      triggerNotification(e.message || "Gagal tersambung dengan API, menggunakan contoh offline.", "error");
    } finally {
      setIsLoadingContext(false);
    }
  };

  // Fetch initial Brand Context on load / BrandId switch
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadBrandContext();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedBrandId, connectionStatus, fallbackModeActive]);

  // Step 3 Content Context Editor Handlers
  const handleAddContextValue = (path: string) => {
    if (!tempInputValue.trim() || !editableContext) return;
    const cloned = JSON.parse(JSON.stringify(editableContext));

    if (path === "brandIdentity.values") {
      cloned.brandIdentity.values.push(tempInputValue);
    } else if (path === "audience.segments") {
      cloned.audience.segments.push(tempInputValue);
    } else if (path === "audience.painPoints") {
      cloned.audience.painPoints.push(tempInputValue);
    } else if (path === "audience.desires") {
      cloned.audience.desires.push(tempInputValue);
    } else if (path === "brandRules.doRules") {
      cloned.brandRules.doRules.push(tempInputValue);
    } else if (path === "brandRules.dontRules") {
      cloned.brandRules.dontRules.push(tempInputValue);
    } else if (path === "offers") {
      cloned.offers.push({
        name: tempInputValue,
        benefits: ["High-priority implementation asset"],
        price: "Contact for pricing",
        ctaText: "Discover Premium"
      });
    }

    setEditableContext(cloned);
    setTempInputValue("");
    setEditingFieldType(null);
    triggerNotification("Parameter Brand berhasil ditambahkan ke draf", "info");
  };

  const handleRemoveContextValue = (path: string, index: number) => {
    if (!editableContext) return;
    const cloned = JSON.parse(JSON.stringify(editableContext));

    if (path === "brandIdentity.values") {
      cloned.brandIdentity.values.splice(index, 1);
    } else if (path === "audience.segments") {
      cloned.audience.segments.splice(index, 1);
    } else if (path === "audience.painPoints") {
      cloned.audience.painPoints.splice(index, 1);
    } else if (path === "audience.desires") {
      cloned.audience.desires.splice(index, 1);
    } else if (path === "brandRules.doRules") {
      cloned.brandRules.doRules.splice(index, 1);
    } else if (path === "brandRules.dontRules") {
      cloned.brandRules.dontRules.splice(index, 1);
    } else if (path === "offers") {
      cloned.offers.splice(index, 1);
    }

    setEditableContext(cloned);
    triggerNotification("Parameter Brand berhasil diedit", "info");
  };

  // Step 5 Calendar Generator API trigger
  const handleGenerateCalendar = async () => {
    if (!editableContext) {
      triggerNotification("Pastikan Anda sudah memilih atau mengisi data Brand terlebih dahulu.", "error");
      return;
    }

    setIsGeneratingCalendar(true);
    setSelectedCalendarItemId(null);
    setActiveDailyDetails(null);

    const actualDays = campaignDuration === "custom" ? customDurationDays : parseInt(campaignDuration);

    try {
      const res = await fetch("/api/gemini/calendar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          brandContext: editableContext,
          durationDays: actualDays,
          objective: campaignObjective
        })
      });

      if (!res.ok) throw new Error("Gemini API failed to generate schema.");
      const data = await res.json();
      
      if (data.error) throw new Error(data.error);

      // Map unique IDs onto the calendar so we can manipulate individually in Step 6
      const formatted: CalendarItem[] = data.calendar.map((item: any, i: number) => ({
        ...item,
        id: `cal-item-gen-${idCounter}-${i}`,
        dayIndex: item.dayIndex || i + 1
      }));

      setIdCounter(prev => prev + 1);
      setGeneratedCalendar(formatted);
      triggerNotification(`Kalender draf berhasil dibuat: ${formatted.length} hari konten promosi dirancang untuk ${campaignObjective}!`);
    } catch (e: any) {
      console.error(e);
      triggerNotification(e.message || "Gagal membuat draf kalender. Pastikan kunci API sudah benar diatur.", "error");
    } finally {
      setIsGeneratingCalendar(false);
    }
  };

  // Step 6 Calendar Review - Manual Modifications
  const handleDeleteCalendarItem = (itemId: string) => {
    const updated = generatedCalendar.filter(item => item.id !== itemId)
      .map((item, i) => ({ ...item, dayIndex: i + 1 })); // Recalculate Day index
    setGeneratedCalendar(updated);
    if (selectedCalendarItemId === itemId) {
      setSelectedCalendarItemId(null);
      setActiveDailyDetails(null);
    }
    triggerNotification("Konten hari tersebut berhasil dihapus.", "info");
  };

  const handleDuplicateCalendarItem = (item: CalendarItem) => {
    const updated = [...generatedCalendar];
    const index = updated.findIndex(i => i.id === item.id);
    if (index === -1) return;

    const duplicatedItem: CalendarItem = {
      ...JSON.parse(JSON.stringify(item)),
      id: `cal-item-dup-${idCounter}`,
      dayIndex: item.dayIndex + 1
    };

    setIdCounter(prev => prev + 1);

    // Insert duplicating item immediately following standard index
    updated.splice(index + 1, 0, duplicatedItem);

    // Refresh all chronological indices
    const chronologicallyIndexed = updated.map((item, i) => ({
      ...item,
      dayIndex: i + 1
    }));

    setGeneratedCalendar(chronologicallyIndexed);
    triggerNotification(`Berhasil mendandakan konten ke Hari ${item.dayIndex + 1}! ✨`);
  };

  const handleSaveEditedItem = () => {
    if (!editingCalendarItem) return;
    const updated = generatedCalendar.map(item => 
      item.id === editingCalendarItem.id ? editingCalendarItem : item
    );
    setGeneratedCalendar(updated);
    setEditingCalendarItem(null);
    triggerNotification("Perubahan detail konten harian berhasil disimpan!");
  };

  // Step 7 Select item & generate day copy
  const handleSelectCalendarItem = async (item: CalendarItem) => {
    setSelectedCalendarItemId(item.id);
    
    // Check if we've already generated detail for this item in this plan session
    if (item.isInflated && item.inflatedDetails) {
      setActiveDailyDetails(item.inflatedDetails);
      return;
    }

    setIsGeneratingDaily(true);
    setActiveDailyDetails(null);

    try {
      const res = await fetch("/api/gemini/content-detail", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          calendarItem: item,
          brandContext: editableContext
        })
      });

      if (!res.ok) throw new Error("Failed to inflate details for content day.");
      const data = await res.json();

      if (data.error) throw new Error(data.error);

      const details: DailyDetails = data.details;

      // Update calendar state to store these details to avoid redundant API loads
      const updated = generatedCalendar.map(c => {
        if (c.id === item.id) {
          return {
            ...c,
            isInflated: true,
            inflatedDetails: details
          };
        }
        return c;
      });

      setGeneratedCalendar(updated);
      setActiveDailyDetails(details);
      triggerNotification(`Konten Kreatif AI Berhasil Dibuat untuk Hari ${item.dayIndex}! ✍️`);
    } catch (e: any) {
      console.error(e);
      triggerNotification(e.message || "Gagal memuat teks promosi AI.", "error");
    } finally {
      setIsGeneratingDaily(false);
    }
  };

  // Dynamic status-colored background tags for Funnel Stages
  const getStageBadge = (stage: string) => {
    switch (stage) {
      case "TOFU":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "MOFU":
        return "bg-emerald-50 text-emerald-700 border-emerald-200";
      case "BOFU":
        return "bg-orange-50 text-orange-700 border-orange-200";
      default:
        return "bg-slate-50 text-slate-700 border-slate-200";
    }
  };

  // Step 8: Content Library save
  const handleSaveToLibrary = (status: "Draft" | "Approved" | "Scheduled" | "Published") => {
    if (!selectedCalendarItemId || !activeDailyDetails || !editableContext) return;

    const calendarItem = generatedCalendar.find(i => i.id === selectedCalendarItemId);
    if (!calendarItem) return;

    const newLibraryItem: LibraryItem = {
      id: `lib-asset-${idCounter}`,
      calendarItem: {
        id: calendarItem.id,
        dayIndex: calendarItem.dayIndex,
        funnelStage: calendarItem.funnelStage,
        contentObjective: calendarItem.contentObjective,
        contentFormat: calendarItem.contentFormat,
        topic: calendarItem.topic,
        hook: calendarItem.hook,
        cta: calendarItem.cta
      },
      details: activeDailyDetails,
      brandName: editableContext.brandName,
      status,
      createdDate: new Date().toLocaleDateString("id-ID", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })
    };

    const updatedLibrary = [newLibraryItem, ...savedLibrary];
    setSavedLibrary(updatedLibrary);
    setIdCounter(prev => prev + 1);
    localStorage.setItem("alco_content_library_db", JSON.stringify(updatedLibrary));
    triggerNotification(`Konten berhasil disimpan ke Galeri sebagai *${status}*! 📥`);
  };

  // Delete from Library
  const handleDeleteLibraryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedLibrary.filter(item => item.id !== id);
    setSavedLibrary(updated);
    localStorage.setItem("alco_content_library_db", JSON.stringify(updated));
    triggerNotification("Konten dihapus dari Galeri.", "info");
  };

  const handleUpdateLibraryStatus = (id: string, status: "Draft" | "Approved" | "Scheduled" | "Published") => {
    const updated = savedLibrary.map(item => {
      if (item.id === id) {
        return { ...item, status };
      }
      return item;
    });
    setSavedLibrary(updated);
    localStorage.setItem("alco_content_library_db", JSON.stringify(updated));
    triggerNotification(`Status Konten berhasil diubah menjadi ${status}.`);
  };

  // Clipboard copy handler
  const copyTextToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTextState(label);
    triggerNotification(`Berhasil menyalin ${label} ke memori HP/Komputer Anda! 📋`);
    setTimeout(() => {
      setCopiedTextState(null);
    }, 2000);
  };

  // Configuration map for the step wizard
  const configDataMapped = {
    startDate: calStartDate,
    setStartDate: setCalStartDate,
    coreTopic: calCoreTopic,
    setCoreTopic: setCalCoreTopic,
    campaignDuration: calCampaignDuration,
    setCampaignDuration: setCalCampaignDuration,
    formats: calFormats,
    toggleFormat: (fmt: string) => {
      setCalFormats(prev => prev.includes(fmt) ? prev.filter(f => f !== fmt) : [...prev, fmt]);
    },
    carouselSlides: calCarouselSlides,
    setCarouselSlides: setCalCarouselSlides,
    reelsDuration: calReelsDuration,
    setReelsDuration: setCalReelsDuration,
    ratio: calRatio,
    setRatio: setCalRatio,
    formatRatio: calFormatRatio,
    setFormatRatio: setCalFormatRatio,
    selectedVoices: calSelectedVoices,
    toggleVoice: (v: string) => {
      setCalSelectedVoices(prev => prev.includes(v) ? prev.filter(x => x !== v) : [...prev, v]);
    },
    hookMix: calHookMix,
    updateHookMix: (idx: number, key: string, value: any) => {
      setCalHookMix(prev => prev.map((item, i) => i === idx ? { ...item, [key]: value } : item));
    },
    referenceType: calReferenceType,
    setReferenceType: setCalReferenceType,
    selectedCTAs: calSelectedCTAs,
    toggleCTA: (cta: string) => {
      setCalSelectedCTAs(prev => prev.includes(cta) ? prev.filter(x => x !== cta) : [...prev, cta]);
    },
    selectedFormula: calSelectedFormula,
    setSelectedFormula: setCalSelectedFormula,
    isFastMode: calIsFastMode,
    setIsFastMode: setCalIsFastMode,
    gender: calGender,
    setGender: setCalGender,
    ageRange: calAgeRange,
    setAgeRange: setCalAgeRange,
    skipDays: calSkipDays,
    toggleSkipDay: (day: string) => {
      setCalSkipDays(prev => prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]);
    },
    generateContent: handleGenerateStrategyFromCalendarView,
    brandContext: brandContext,
    editableContext: editableContext,
    selectedProject: selectedProject,
    connectionStatus: connectionStatus
  };

  // Filter local Library array
  const filteredLibrary = savedLibrary.filter(item => {
    if (libraryFilterStatus === "All") return true;
    return item.status === libraryFilterStatus;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-900">
      
      {/* Dynamic API status overlay notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-lg border shadow-lg text-sm font-medium ${
              notification.type === "success" 
                ? "bg-emerald-50 text-emerald-800 border-emerald-200" 
                : notification.type === "error" 
                ? "bg-red-50 text-red-800 border-red-200" 
                : "bg-slate-900 text-slate-100 border-slate-800"
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${
              notification.type === "success" ? "bg-emerald-500" 
              : notification.type === "error" ? "bg-red-500" 
              : "bg-blue-400"
            }`} />
            <span>{notification.message}</span>
            <button onClick={() => setNotification(null)} className="ml-2 hover:opacity-75 transition">
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header section (Aesthetic design: clean off-white frame, Professional Polish style) */}
      <header id="alco-header" className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg italic shadow-md">
              A
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-slate-900 uppercase">ALCO Content OS</h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-500 border border-slate-200 font-semibold tracking-wider">
                  Engine Core
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono font-medium">
                {connectionStatus === "active" ? (
                  <span className="text-emerald-500 font-bold">● API Active • Synced Core</span>
                ) : fallbackModeActive ? (
                  <span className="text-amber-500 font-semibold">▲ Failover • Sandbox Mode</span>
                ) : connectionStatus === "failed" ? (
                  <span className="text-red-500 font-semibold">■ Connection Failed • Action Required</span>
                ) : (
                  <span className="text-slate-400 font-medium">○ API Disconnected • Setup Needed</span>
                )}
              </p>
            </div>
          </div>

          {/* Navigation and workspace info */}
          {connectionStatus === "active" || fallbackModeActive ? (
            <div className="flex items-center gap-2.5">
              <Link
                href="/data-source"
                className="bg-blue-50 hover:bg-blue-105 hover:bg-blue-100 text-blue-700 border border-blue-200 px-3 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition"
                title="Atur model data referensi / Data Source Manager"
              >
                <Database size={12} className="text-blue-600" />
                <span>DATA SOURCE</span>
              </Link>

              <button
                id="tab-btn-architect"
                onClick={() => setActiveViewTab("architect")}
                className={`flex items-center gap-2 text-xs font-mono tracking-tight px-4 py-2 rounded-lg border transition duration-150 ${
                  activeViewTab === "architect"
                    ? "bg-blue-600 text-white border-blue-700 shadow-sm font-semibold"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
              >
                <Sliders size={13} />
                CAMPAIGN ARCHITECT
              </button>
              <button
                id="tab-btn-library"
                onClick={() => setActiveViewTab("library")}
                className={`flex items-center gap-2 text-xs font-mono tracking-tight px-4 py-2 rounded-lg border transition duration-150 relative ${
                  activeViewTab === "library"
                    ? "bg-blue-600 text-white border-blue-700 shadow-sm font-semibold"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
              >
                <BookOpen size={13} />
                ASSET LIBRARY
                {savedLibrary.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white text-[9px] w-5 h-5 rounded-full flex items-center justify-center font-bold font-mono shadow-sm">
                    {savedLibrary.length}
                  </span>
                )}
              </button>
              
              <button
                onClick={() => {
                  setConnectionStatus("disconnected");
                  setFallbackModeActive(false);
                  setBrandContext(null);
                  setEditableContext(null);
                  localStorage.removeItem("alco_api_url");
                  localStorage.removeItem("alco_api_key");
                  localStorage.removeItem("alco_fallback_mode_active");
                  localStorage.removeItem("alco_imported_dossier");
                  triggerNotification("Sambungan API diputuskan.", "info");
                }}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-3 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition"
                title="Disconnect from App 1 Core API"
              >
                <WifiOff size={13} className="text-red-500 shrink-0" />
                <span>DISCONNECT</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2.5 font-mono">
              <Link
                href="/data-source"
                className="bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
                title="Buka Data Source Manager"
              >
                <Database size={13} />
                <span>DATA SOURCE MANAGER</span>
              </Link>
              <span className="text-[10px] uppercase font-bold text-slate-400 border border-dashed border-slate-200 px-3 py-1.5 rounded-lg bg-slate-50 flex items-center gap-1.5">
                🔒 GATEWAY GATE AUTH REQUIRED
              </span>
            </div>
          )}

        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 md:px-6 py-6">

        {/* Tab 1: Campaign Architect Workspace */}
        {activeViewTab === "architect" && (
          <div className="space-y-6">
            {/* API BRIDGE COMPACT STATUS BAR */}
            <div className="w-full font-mono text-xs">
              <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row items-center justify-between shadow-sm transition duration-150 gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-[10px] tracking-widest text-slate-400 font-bold uppercase">INTELLIGENCE SOURCE:</span>
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${connectionStatus === "active" ? "bg-emerald-500 animate-pulse" : fallbackModeActive ? "bg-amber-500 animate-ping" : "bg-slate-350"}`} />
                    {connectionStatus === "active" ? `CONNECTED GATEWAY (${apiBaseUrl})` : fallbackModeActive ? "OFFLINE HOVER SANDBOX" : "UNPAIRED / OFFLINE"}
                  </span>
                  <span className="text-slate-200 hidden sm:inline">|</span>
                  <span className="text-[10px] text-slate-500">Sync: {lastSync}</span>
                  {connectionStatus === "active" && (
                    <span className="text-[9px] text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md font-bold">
                      {detectedBrandsCount} Brands Synced
                    </span>
                  )}
                  {fallbackModeActive && (
                    <span className="text-[9px] text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md font-bold">
                      Local Dossier Active
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Link
                    href="/api-connection"
                    className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-750 border border-slate-200 px-3.5 py-1.5 rounded-lg text-slate-700 font-bold uppercase tracking-wider transition flex items-center gap-1"
                  >
                    <Globe size={11} className="text-blue-500" />
                    Configure API Setup
                  </Link>
                </div>
              </div>
            </div>

            {/* First Page / Landing Portal: Connection Center Gateway */}
            {connectionStatus !== "active" && !fallbackModeActive ? (
              <div className="max-w-3xl mx-auto py-16 animate-fadeIn space-y-10">
                
                {/* Header Identity banner */}
                <div className="text-center space-y-4">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-[11px] font-sans font-bold uppercase tracking-wider border border-blue-200">
                    <Sparkles size={11} className="text-blue-500 animate-pulse" /> ASISTEN KONTEN AI ELITE
                  </div>
                  <h2 className="text-4xl font-extrabold text-slate-900 font-sans tracking-tight">
                    ALCO Content OS <span className="text-blue-600">v2.1</span>
                  </h2>
                  <p className="text-sm text-slate-500 font-sans max-w-xl mx-auto leading-relaxed">
                    Solusi instan untuk membantu pemula dan pemilik bisnis membuat rencana konten & draf promosi media sosial bulanan secara otomatis tanpa panduan teknis yang rumit.
                  </p>
                </div>

                {/* Unpaired Option Prompt Card */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                  
                  {/* Option 1: Sandbox / Instant Launch (Main recommendation) */}
                  <div className="bg-gradient-to-b from-blue-50/50 to-white hover:from-blue-50/90 border-2 border-blue-500/30 hover:border-blue-500/80 rounded-2xl p-6 shadow-sm hover:shadow-md transition duration-300 flex flex-col justify-between text-left space-y-4">
                    <div className="space-y-2">
                      <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center text-lg font-bold shadow-md">
                        ✨
                      </div>
                      <h3 className="text-base font-bold text-slate-900 tracking-tight">
                        Mulai Instan (Bebas & Gratis)
                      </h3>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        Rancang kalender promosi kustom Anda secara offline langsung tanpa pengaturan API atau akun server. Sangat cocok dan mudah untuk pemula!
                      </p>
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => {
                        setFallbackModeActive(true);
                        setConnectionStatus("disconnected");
                        setSelectedBrandId("custom");
                        localStorage.setItem("alco_fallback_mode_active", "true");
                        triggerNotification("Mode Mandiri (Offline) Aktif! Selamat berkarya rilis rancangan Anda.", "info");
                        loadBrandContext(); 
                      }}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-xs font-bold transition shadow-sm hover:shadow text-center flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Mulai Sekarang</span>
                      <ChevronRight size={14} />
                    </button>
                  </div>

                  {/* Option 2: Data Source Manager */}
                  <div className="bg-white hover:bg-slate-50/60 border border-slate-200 hover:border-slate-350 rounded-2xl p-6 shadow-sm hover:shadow-md transition duration-300 flex flex-col justify-between text-left space-y-4">
                    <div className="space-y-2">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-lg font-bold">
                        📂
                      </div>
                      <h3 className="text-base font-bold text-slate-900 tracking-tight">
                        Impor Template (JSON)
                      </h3>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        Muat strategi bisnis yang sudah disimpan sebelumnya melalui berkas data lokal atau salinan teks mentah.
                      </p>
                    </div>
                    
                    <Link
                      href="/data-source"
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-xl text-xs font-bold transition shadow-sm text-center flex items-center justify-center gap-1.5"
                    >
                      <span>Buka Profil Data</span>
                    </Link>
                  </div>

                  {/* Option 3: Connection Settings */}
                  <div className="bg-white hover:bg-slate-50/60 border border-slate-200 hover:border-slate-350 rounded-2xl p-6 shadow-sm hover:shadow-md transition duration-300 flex flex-col justify-between text-left space-y-4">
                    <div className="space-y-2">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-lg font-bold">
                        🔗
                      </div>
                      <h3 className="text-base font-bold text-slate-900 tracking-tight font-sans">
                        Sambungkan API (Pro)
                      </h3>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        Otorisasi dan sinkronisasi otomatis informasi dari App 1 Intelligence secara real-time untuk fitur profesional multi-brand.
                      </p>
                    </div>
                    
                    <Link
                      href="/api-connection"
                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 hover:text-slate-900 border border-slate-200 py-3 rounded-xl text-xs font-bold transition text-center flex items-center justify-center gap-1.5"
                    >
                      <span>Hubungkan Server</span>
                    </Link>
                  </div>

                </div>

                <p className="text-center text-xs font-sans text-slate-450 max-w-md mx-auto">
                  🔒 data Anda sepenuhnya aman. Seluruh data kredensial dan draf tulisan kustom disimpan secara privat dalam memori browser lokal Anda.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">

                {/* left third: setup rails (Step 1, 2, 3) */}
                <div className="lg:col-span-4 flex flex-col gap-6">

              {/* STEP 1 Card */}
              <div id="step-1-card" className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-mono text-[10px] flex items-center justify-center font-bold shadow-sm">1</span>
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-700">Pilih Ruang Kerja</h3>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed">
                  Silakan pilih lingkungan kerja dan proyek kampanye Anda di bawah ini untuk memulai membuat konten promosi secara otomatis.
                </p>

                {connectionStatus === "active" && dynamicProjects.length === 0 && (
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-xs text-blue-900 space-y-2 font-sans">
                    <p className="font-bold flex items-center gap-1.5 text-blue-800">
                      <span>💡</span> API Berhasil Terhubung
                    </p>
                    <p className="text-[11px] text-blue-700 leading-relaxed">
                      Koneksi berhasil dan aktif! Namun, akun database API Anda saat ini belum memiliki proyek atau brand kustom. 
                      Kami memuat <strong>proyek contoh (Sandbox)</strong> secara otomatis agar Anda dapat langsung merancang konten promosi Anda sekarang!
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  {connectionStatus === "active" && dynamicProjects.length > 0 ? (
                    <>
                      {/* Workspace selection */}
                      <div>
                        <label className="block text-xs uppercase text-slate-500 mb-1.5 font-bold">
                          Pilih Ruang Kerja API
                        </label>
                        <div className="relative">
                          <select 
                            value={selectedWorkspace}
                            onChange={(e) => setSelectedWorkspace(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg text-sm px-3 py-2 text-slate-800 focus:outline-none focus:border-slate-400 transition duration-150 font-medium"
                          >
                            {Array.from(new Set(dynamicProjects.map(p => p.workspace).filter(Boolean))).map(ws => (
                              <option key={ws} value={ws}>{ws}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Project selection */}
                      <div>
                        <label className="block text-xs uppercase text-slate-500 mb-1.5 font-bold">
                          Pilih Proyek Kampanye API
                        </label>
                        <select 
                          value={selectedProject}
                          onChange={(e) => setSelectedProject(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg text-sm px-3 py-2 text-slate-800 focus:outline-none focus:border-slate-400 transition duration-150 font-medium"
                        >
                          {dynamicProjects
                            .filter(p => !selectedWorkspace || p.workspace === selectedWorkspace)
                            .map(pj => (
                              <option key={pj.name} value={pj.name}>{pj.name}</option>
                            ))}
                        </select>
                      </div>
                    </>
                  ) : (
                    <div className="bg-stone-50/60 p-3.5 rounded-xl border border-stone-150 text-xs text-stone-700 font-sans space-y-1.5">
                      <div className="font-bold flex items-center gap-1.5 text-slate-800">
                        <span>🏠</span> Ruang Kerja: <span className="text-blue-650 font-extrabold">Instant Sandbox</span>
                      </div>
                      <p className="text-[11px] text-stone-500 leading-relaxed font-sans">
                        Mode instan mendeteksi Anda berjalan di ruang kerja bebas. Tidak memerlukan server! Sempurna untuk merancang draf secara cepat.
                      </p>
                    </div>
                  )}

                  {/* Brand Selector */}
                  <div>
                    <label className="block text-xs uppercase text-slate-500 mb-1.5 font-bold">
                      {connectionStatus === "active" && dynamicBrands.length > 0 ? "Pilih Model Informasi Brand API" : "Pilih Struktur Profil Usaha"}
                    </label>
                    <div className="grid grid-cols-1 gap-2">
                      {connectionStatus === "active" && dynamicBrands.length > 0 ? (
                        dynamicBrands.map(brand => (
                          <button
                            key={brand.id}
                            onClick={() => {
                              setSelectedBrandId(brand.id);
                              fetchSelectedBrandContext(brand.id, apiBaseUrl, apiToken);
                            }}
                            className={`flex flex-col items-start p-3 rounded-lg border text-left transition duration-150 cursor-pointer ${
                              selectedBrandId === brand.id 
                                ? "bg-blue-50/50 border-blue-500 shadow-sm" 
                                : "bg-white hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            <div className="flex items-center justify-between w-full">
                              <span className={`text-xs font-semibold ${selectedBrandId === brand.id ? "text-blue-900 font-bold" : "text-slate-700"}`}>
                                ⚜️ {brand.name}
                              </span>
                              {selectedBrandId === brand.id && (
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse" />
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 mt-1">{brand.desc}</span>
                          </button>
                        ))
                      ) : (
                        PRESET_BRANDS.map(brand => (
                          <button
                            key={brand.id}
                            onClick={() => {
                              setSelectedBrandId(brand.id);
                              // Auto load fallback presets
                              if (brand.id === "custom") {
                                loadBrandContext();
                              }
                            }}
                            className={`flex flex-col items-start p-3 rounded-lg border text-left transition duration-150 cursor-pointer ${
                              selectedBrandId === brand.id 
                                ? "bg-blue-50/50 border-blue-500 shadow-sm" 
                                : "bg-white hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            <div className="flex items-center justify-between w-full">
                              <span className={`text-xs font-semibold ${selectedBrandId === brand.id ? "text-blue-900 font-bold" : "text-slate-700"}`}>
                                {brand.name === "+ Custom Brand Intelligence" ? "💡 Buat Strategi Brand Sendiri (Kustom)" : brand.name}
                              </span>
                              {selectedBrandId === brand.id && (
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 mt-1">
                              {brand.id === "custom" ? "Tentukan suara promosi, target pembeli & rincian penawaran Anda sendiri" : brand.desc}
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* STEP 2 & 3: Custom Brand Inputs (Visual display only if 'custom' is selected) */}
              {selectedBrandId === "custom" && (
                <div id="custom-parameters-card" className="bg-white rounded-2xl border border-blue-100 p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                    <Sparkles size={16} className="text-amber-500 animate-pulse" />
                    <h3 className="text-sm font-bold text-slate-800 uppercase tracking-tight">Atur Profil Bisnis Anda</h3>
                  </div>
                  <div className="space-y-4 text-xs font-sans">
                    <div>
                      <label className="block text-slate-600 mb-1.5 font-bold">Nama Bisnis / Brand Anda</label>
                      <input 
                        type="text" 
                        value={customBrandName}
                        onChange={(e) => setCustomBrandName(e.target.value)}
                        placeholder="Contoh: Aura Glow Skincare, Kopi Sejahtera"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-600 mb-1.5 font-bold">Gaya Bicara Konten</label>
                        <input 
                          type="text" 
                          value={customVoice}
                          onChange={(e) => setCustomVoice(e.target.value)}
                          placeholder="Contoh: Sahabat karib, edukatif, kasual"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-1.5 font-bold">Nada Penulisan</label>
                        <input 
                          type="text" 
                          value={customTone}
                          onChange={(e) => setCustomTone(e.target.value)}
                          placeholder="Contoh: Hangat, humoris, optimis"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-600 mb-1.5 font-bold">Keunggulan Utama / Solusi Produk</label>
                      <textarea 
                        value={customCorePromise}
                        onChange={(e) => setCustomCorePromise(e.target.value)}
                        placeholder="Terangkan solusi terbaik produk Anda..."
                        rows={2}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition resize-none leading-relaxed"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-600 mb-1.5 font-bold">Target Pembeli / Konsumen Terbaik</label>
                      <input 
                        type="text" 
                        value={customAudience}
                        placeholder="Contoh: Ibu-ibu muda, pelajar, pemilik kafe"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-600 mb-1.5 font-bold">Nama Produk Utama</label>
                        <input 
                          type="text" 
                          value={customOfferName}
                          placeholder="Contoh: Paket Glowing, Kopi Espresso"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-1.5 font-bold">Harga Jual (Opsional)</label>
                        <input 
                          type="text" 
                          value={customOfferPrice}
                          placeholder="Contoh: Rp 150.000"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-blue-500 focus:bg-white transition"
                        />
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        onClick={loadBrandContext}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-sans text-xs py-3 rounded-xl uppercase font-bold tracking-wider hover:shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>💾 Simpan & Terapkan Profil</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 3 Panel: Tampilkan brand context database dari API */}
              <div id="brand-dossier-card" className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-mono text-[10px] flex items-center justify-center font-bold shadow-sm">3</span>
                    <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">Brand Strategy Dossier</h3>
                  </div>
                  <button 
                    onClick={loadBrandContext} 
                    disabled={isLoadingContext}
                    className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition duration-150"
                    title="Reload from API"
                  >
                    <RefreshCcw size={13} className={isLoadingContext ? "animate-spin" : ""} />
                  </button>
                </div>

                {isLoadingContext ? (
                  <div className="py-12 text-center text-xs text-slate-400 font-mono tracking-wider space-y-2">
                    <RefreshCcw size={18} className="animate-spin mx-auto text-blue-500" />
                    <span>Synchronizing Intelligence...</span>
                  </div>
                ) : brandContext ? (
                  <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
                    
                    {/* Header */}
                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                      <div className="text-[10px] uppercase font-mono text-slate-400">Context Source</div>
                      <div className="text-sm font-semibold text-slate-800 uppercase tracking-tight">{brandContext.brandName}</div>
                      <div className="mt-1 text-xs text-slate-600 italic">&quot;{brandContext.positioning?.corePromise}&quot;</div>
                    </div>

                    {/* Step 3 - Brand Voice & Tone parameters */}
                    <div className="text-xs space-y-1.5 border-b border-slate-100 pb-3">
                      <div className="font-mono text-[10px] uppercase text-slate-400 font-semibold tracking-wider">Identity Settings</div>
                      <p className="text-slate-750"><strong>Voice Accent:</strong> {brandContext.brandIdentity?.voice}</p>
                      <p className="text-slate-755"><strong>Tone Rules:</strong> {brandContext.brandIdentity?.tone}</p>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {editableContext?.brandIdentity?.values?.map((val, i) => (
                          <span key={i} className="bg-slate-50 px-1.5 py-0.5 rounded text-[10px] text-slate-600 border border-slate-200 flex items-center gap-1 font-medium">
                            {val}
                            <button onClick={() => handleRemoveContextValue("brandIdentity.values", i)} className="text-slate-400 hover:text-red-500 font-bold">×</button>
                          </span>
                        ))}
                        <button 
                          onClick={() => setEditingFieldType("brandIdentity.values")}
                          className="bg-slate-50 border border-dashed border-slate-300 px-1.5 py-0.5 rounded text-[10px] text-slate-500 hover:border-blue-600 hover:text-blue-600 transition"
                        >
                          + Add Value
                        </button>
                      </div>
                    </div>

                    {/* Step 3 - Target audience segments */}
                    <div className="text-xs space-y-1.5 border-b border-slate-100 pb-3">
                      <div className="font-mono text-[10px] uppercase text-slate-400 font-semibold tracking-wider">Target Audience Segments</div>
                      <div className="space-y-1">
                        {editableContext?.audience?.segments?.map((seg, i) => (
                          <div key={i} className="bg-slate-50 p-2 rounded border border-slate-200/50 flex justify-between items-start gap-1">
                            <span className="text-slate-700">{seg}</span>
                            <button onClick={() => handleRemoveContextValue("audience.segments", i)} className="text-slate-400 hover:text-red-500 font-bold text-xs ml-1">×</button>
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={() => setEditingFieldType("audience.segments")}
                        className="text-[10px] font-mono text-blue-600 hover:text-blue-700 underline block mt-1"
                      >
                        + Add Custom Segment
                      </button>
                    </div>

                    {/* Step 3 - Pain points & desires */}
                    <div className="text-xs space-y-2 border-b border-slate-100 pb-3">
                      <div className="font-mono text-[10px] uppercase text-slate-500 font-semibold tracking-wider">Pain Points & Desires</div>
                      <div>
                        <div className="text-[10px] font-mono text-slate-400 uppercase font-medium">Core Pain Points</div>
                        <ul className="list-disc list-inside space-y-0.5 mt-1 text-slate-700">
                          {editableContext?.audience?.painPoints?.map((pp, i) => (
                            <li key={i} className="text-slate-650 hover:text-slate-800">
                              {pp}
                              <button onClick={() => handleRemoveContextValue("audience.painPoints", i)} className="text-red-400 hover:text-red-650 ml-1.5 text-xs">×</button>
                            </li>
                          ))}
                        </ul>
                        <button 
                          onClick={() => setEditingFieldType("audience.painPoints")}
                          className="text-[9px] font-mono text-slate-400 hover:text-slate-650 underline mt-1"
                        >
                          + Append Pain Point
                        </button>
                      </div>

                      <div>
                        <div className="text-[10px] font-mono text-slate-400 uppercase font-medium">Customer Desires</div>
                        <ul className="list-disc list-inside space-y-0.5 mt-1 text-slate-700">
                          {editableContext?.audience?.desires?.map((des, i) => (
                            <li key={i} className="text-slate-650 hover:text-slate-850">
                              {des}
                              <button onClick={() => handleRemoveContextValue("audience.desires", i)} className="text-red-405 hover:text-red-650 ml-1.5 text-xs">×</button>
                            </li>
                          ))}
                        </ul>
                        <button 
                          onClick={() => setEditingFieldType("audience.desires")}
                          className="text-[9px] font-mono text-slate-400 hover:text-slate-600 underline mt-1"
                        >
                          + Append Desire
                        </button>
                      </div>
                    </div>

                    {/* Step 3 - Marketing Offers */}
                    <div className="text-xs space-y-1.5 border-b border-slate-100 pb-3">
                      <div className="font-mono text-[10px] uppercase text-slate-400 font-semibold tracking-wider">Current Valued Offer (CTA Targets)</div>
                      <div className="space-y-1.5">
                        {editableContext?.offers?.map((of, i) => (
                          <div key={i} className="bg-blue-50/40 p-2.5 py-1.5 rounded border border-blue-100 text-[11px]">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-slate-800">{of.name}</span>
                              <button onClick={() => handleRemoveContextValue("offers", i)} className="text-slate-400 hover:text-red-500 font-bold ml-1">×</button>
                            </div>
                            <div className="text-slate-500 font-mono text-[10px] mt-0.5 font-medium">{of.price} • CTA: &quot;{of.ctaText}&quot;</div>
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={() => setEditingFieldType("offers")}
                        className="text-[10px] font-mono text-blue-600 hover:text-blue-700 underline block mt-1"
                      >
                        + Add Custom Offer Unit
                      </button>
                    </div>

                    {/* Step 3 - Brand Rules Checklist */}
                    <div className="text-xs space-y-2 pb-1">
                      <div className="font-mono text-[10px] uppercase text-slate-400 font-semibold tracking-wider">Styling Guardrails</div>
                      <div>
                        <div className="text-[10px] text-emerald-600 uppercase font-semibold font-mono">DO - Always Apply:</div>
                        <ul className="list-disc list-inside space-y-0.5 mt-1 text-slate-650">
                          {editableContext?.brandRules?.doRules?.map((rule, i) => (
                            <li key={i}>
                              {rule}
                              <button onClick={() => handleRemoveContextValue("brandRules.doRules", i)} className="text-slate-400 hover:text-red-400 ml-1.5">×</button>
                            </li>
                          ))}
                        </ul>
                        <button onClick={() => setEditingFieldType("brandRules.doRules")} className="text-[9px] font-mono text-slate-405 block underline mt-0.5">+ Add Rule</button>
                      </div>
                      <div>
                        <div className="text-[10px] text-red-500 uppercase font-semibold font-mono">DONT - Prohibited:</div>
                        <ul className="list-disc list-inside space-y-0.5 mt-1 text-slate-650">
                          {editableContext?.brandRules?.dontRules?.map((rule, i) => (
                            <li key={i}>
                              {rule}
                              <button onClick={() => handleRemoveContextValue("brandRules.dontRules", i)} className="text-slate-400 hover:text-red-400 ml-1.5">×</button>
                            </li>
                          ))}
                        </ul>
                        <button onClick={() => setEditingFieldType("brandRules.dontRules")} className="text-[9px] font-mono text-slate-405 block underline mt-0.5">+ Add Prohibited</button>
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="py-6 text-center text-xs text-slate-400 font-mono">
                    Please configure parameters or select preset brand.
                  </div>
                )}

                {/* Inline Editing Popup modal inside column */}
                <AnimatePresence>
                  {editingFieldType && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="mt-3 bg-slate-100 p-3 rounded-lg border border-slate-300"
                    >
                      <div className="text-[10px] font-mono text-slate-500 uppercase mb-1">
                        Add to {editingFieldType.split(".").pop()}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={tempInputValue}
                          onChange={(e) => setTempInputValue(e.target.value)}
                          placeholder="Type input here..."
                          className="flex-1 text-xs bg-white border border-slate-300 rounded px-2 py-1 focus:outline-none font-mono focus:border-blue-500"
                          onKeyDown={(e) => e.key === "Enter" && handleAddContextValue(editingFieldType)}
                        />
                        <button
                          onClick={() => handleAddContextValue(editingFieldType)}
                          className="bg-blue-600 hover:bg-blue-700 text-white rounded px-2.5 py-1 text-xs transition duration-150 font-semibold"
                        >
                          Add
                        </button>
                        <button
                          onClick={() => { setEditingFieldType(null); setTempInputValue(""); }}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 rounded px-2.5 py-1 text-xs transition duration-150"
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="mt-4 bg-amber-50/60 rounded-lg p-2.5 border border-amber-200/50 text-[10px] text-slate-600">
                  ⚠️ <strong>Disclaimer:</strong> Edits to brand dossier apply to the current active campaign planner only. They do not overwrite App 1&apos;s main server database directly.
                </div>
              </div>

            </div>

            {/* right two-thirds: planners and content calendar review (Step 4, 5, 6) */}
            <div className="lg:col-span-8 flex flex-col gap-6">

              <CalendarView
                items={calendarItems}
                growthItems={growthCalendarItems}
                onReschedule={handleCalendarReschedule}
                onFilterChange={setFilterTypeCalendar}
                filterType={filterTypeCalendar}
                accessCode={accessCode}
                setAccessCode={setAccessCode}
                isAccessValid={isAccessValid}
                isEditAccessLocked={isEditAccessLocked}
                setShowUnlockModal={setShowUnlockModal}
                accessStatus={{ type: "ELITE PRO Trial", maxContent: 90 }}
                usageStats={{ activeCampaigns: 4, generatedTokens: 124500 }}
                isLoading={isGeneratingCalendar}
                isConfiguring={isConfiguringCalendar}
                setIsConfiguring={setIsConfiguringCalendar}
                currentStep={currentStepCalendar}
                setCurrentStep={setCurrentStepCalendar}
                activeConfigCell={activeConfigCellCalendar}
                setActiveConfigCell={setActiveConfigCellCalendar}
                configData={configDataMapped}
                revisions={revisionsCalendar}
                setRevisions={setRevisionsCalendar}
                onRegenerate={handleGenerateStrategyFromCalendarView}
                onClear={() => setCalendarItems([])}
                onCopy={() => {
                  navigator.clipboard.writeText(JSON.stringify(calendarItems, null, 2));
                  triggerNotification("Berhasil menyalin rencana kalender ke clipboard!", "success");
                }}
                onDownload={() => {
                  triggerNotification("Opsi unduh dokumen CSV tersedia pada postingan aktif.", "success");
                }}
                onUpdateItem={handleCalendarUpdateItem}
                onRegenerateItem={handleCalendarRegenerateItem}
                history={calendarHistory}
                onDeleteHistory={(id) => setCalendarHistory(prev => prev.filter(h => h.id !== id))}
                onClearHistory={() => setCalendarHistory([])}
                onReset={() => {
                  setCalendarItems([]);
                  setRevisionsCalendar({});
                }}
                onLoadHistory={(entry) => setCalendarItems(entry.items)}
                onSendToCalcer={(brief) => triggerNotification("Dokumen singkat kampanye berhasil dikirim ke sistem Calcer.", "info")}
              />

            </div>

          </div>
          )}
          </div>
        )}

        {/* Tab 2: Saved Content Library & Scheduled Posts (Step 8) */}
        {activeViewTab === "library" && (
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm min-h-[550px] flex flex-col">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-6">
              <div>
                <h2 className="text-lg font-bold tracking-tight text-slate-900 uppercase">Brand-Aware Asset Library</h2>
                <p className="text-xs text-slate-500">
                  Fully compiled copies ready for direct copy pasting or social media posting scheduling.
                </p>
              </div>

              {/* Status filter bar */}
              <div className="flex flex-wrap items-center gap-1.5 bg-slate-50 p-1 rounded-lg border border-slate-200">
                {["All", "Draft", "Approved", "Scheduled", "Published"].map(status => (
                  <button
                    key={status}
                    onClick={() => setLibraryFilterStatus(status)}
                    className={`text-xs px-3 py-1.5 rounded-md font-mono transition duration-150 ${
                      libraryFilterStatus === status
                        ? "bg-white text-blue-600 shadow-sm border border-slate-200 font-bold"
                        : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    {status}
                  </button>
                ))}
              </div>
            </div>

            {filteredLibrary.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center py-20">
                <div className="w-12 h-12 rounded-full bg-stone-50 border border-stone-200 flex items-center justify-center text-stone-300 mb-3">
                  <BookOpen size={24} />
                </div>
                <h3 className="text-xs font-mono uppercase text-stone-400">Library displays no catalogued items</h3>
                <p className="text-xs text-stone-500 max-w-sm mt-1">
                  Draft a daily post campaign, hit the Status label saving controls on the active detail board to stack posts in the Library cache.
                </p>
                <button
                  onClick={() => setActiveViewTab("architect")}
                  className="mt-4 bg-stone-900 hover:bg-stone-850 text-white font-mono text-xs px-4 py-2 rounded uppercase font-semibold"
                >
                  Return to Architect
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredLibrary.map(item => {
                  const isExpanded = expandedLibraryItemId === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => setExpandedLibraryItemId(isExpanded ? null : item.id)}
                      className={`group border rounded-lg p-4 cursor-pointer text-left transition flex flex-col justify-between ${
                        isExpanded
                          ? "bg-stone-50 border-stone-900 col-span-3 shadow-md"
                          : "bg-white hover:bg-stone-100/55 border-stone-250 hover:border-stone-400"
                      }`}
                    >
                      <div>
                        
                        <div className="flex items-center justify-between gap-2.5 mb-2.5">
                          <span className={`text-[9px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-full uppercase border ${
                            item.status === "Published" ? "bg-emerald-50 text-emerald-800 border-emerald-200"
                            : item.status === "Scheduled" ? "bg-blue-50 text-blue-800 border-blue-200"
                            : item.status === "Approved" ? "bg-amber-50 text-amber-800 border-amber-250"
                            : "bg-stone-100 text-stone-600 border-stone-200"
                          }`}>
                            ● {item.status}
                          </span>
                          
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-stone-400 font-mono italic">{item.createdDate}</span>
                            <button
                              onClick={(e) => handleDeleteLibraryItem(item.id, e)}
                              className="text-stone-300 hover:text-red-500 p-0.5 ml-1"
                              title="Delete catalog item"
                            >
                              <X size={13} />
                            </button>
                          </div>
                        </div>

                        <div className="mb-2">
                          <div className="text-[10px] text-stone-400 font-mono uppercase">{item.brandName} • DAY {item.calendarItem.dayIndex}</div>
                          <h4 className="text-sm font-semibold text-stone-900 leading-tight tracking-tight mt-0.5 group-hover:underline">
                            {item.calendarItem.topic}
                          </h4>
                        </div>

                        {/* Expandable Preview */}
                        {isExpanded ? (
                          <div className="mt-4 pt-4 border-t border-stone-200 grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs" onClick={(e) => e.stopPropagation()}>
                            
                            {/* Copywrite Section (8 columns) */}
                            <div className="lg:col-span-8 space-y-4">
                              <div className="bg-white p-4 rounded-lg border border-stone-200">
                                <div className="flex items-center justify-between mb-2">
                                  <label className="text-[10px] uppercase font-mono tracking-wider text-stone-400 font-bold block">Social Media Copy Description:</label>
                                  <button
                                    onClick={() => copyTextToClipboard(item.details.caption, "Social Caption")}
                                    className="flex items-center gap-1 text-[10px] font-mono bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded px-2 py-1 text-stone-600 transition"
                                  >
                                    <Copy size={11} />
                                    {copiedTextState === "Social Caption" ? "Copied!" : "Copy Caption"}
                                  </button>
                                </div>
                                <p className="text-stone-700 whitespace-pre-line leading-relaxed font-mono font-medium text-[11px] select-all bg-stone-100/30 p-3 rounded border">
                                  {item.details.caption}
                                </p>
                              </div>

                              <div className="grid grid-cols-2 gap-3 font-mono">
                                <div className="bg-white p-3 rounded-lg border border-stone-200">
                                  <span className="text-[10px] text-stone-400 block lowercase tracking-widest font-semibold mb-1">Interactive Hook:</span>
                                  <span className="text-stone-800 italic">&quot;{item.details.hook}&quot;</span>
                                </div>
                                <div className="bg-white p-3 rounded-lg border border-stone-200">
                                  <span className="text-[10px] text-stone-400 block lowercase tracking-widest font-semibold mb-1">Target Action CTA:</span>
                                  <span className="text-emerald-700 font-bold">{item.details.cta}</span>
                                </div>
                              </div>
                            </div>

                            {/* Graphic Spec section (4 columns) */}
                            <div className="lg:col-span-4 bg-stone-100 p-4 rounded-lg border border-stone-200 space-y-3 font-mono">
                              <div>
                                <span className="text-[10px] uppercase tracking-wider text-stone-550 font-bold block mb-1">Format:</span>
                                <span className="bg-stone-205 border border-stone-300 px-2.5 py-0.5 rounded text-[10px] text-stone-800 font-semibold uppercase">{item.calendarItem.contentFormat}</span>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase tracking-wider text-stone-550 font-bold block mb-1">Visual Direction:</span>
                                <p className="text-[11px] text-stone-600 leading-relaxed italic">&quot;{item.details.visualDirection}&quot;</p>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase tracking-wider text-stone-550 font-bold block mb-1">Design Brief:</span>
                                <p className="text-[11px] text-stone-600 leading-relaxed">{item.details.designBrief}</p>
                              </div>
                              <div className="bg-white p-2 border border-stone-300 rounded text-[10px]">
                                <span className="text-[9px] uppercase font-bold tracking-wider text-stone-400 block">AI Image Generator Prompt:</span>
                                <p className="text-stone-500 italic mt-1 leading-snug">{item.details.imagePrompt}</p>
                              </div>

                              {/* Manual transition controls inside Expanded card */}
                              <div className="pt-3 border-t border-stone-200">
                                <span className="text-[9px] uppercase tracking-widest text-stone-400 block mb-1.5 font-bold">Shift Publication Status:</span>
                                <div className="flex flex-wrap gap-1">
                                  {(["Draft", "Approved", "Scheduled", "Published"] as const).map(st => (
                                    <button
                                      key={st}
                                      onClick={() => handleUpdateLibraryStatus(item.id, st)}
                                      className={`text-[9px] px-2 py-1 rounded transition ${
                                        item.status === st
                                          ? "bg-stone-900 text-white font-bold"
                                          : "bg-white border border-stone-300 hover:bg-stone-50 text-stone-600"
                                      }`}
                                    >
                                      {st}
                                    </button>
                                  ))}
                                </div>
                              </div>

                            </div>

                          </div>
                        ) : (
                          <div className="mt-2 text-xs text-stone-400 flex items-center justify-between font-mono">
                            <span>Format: <strong>{item.calendarItem.contentFormat}</strong></span>
                            <span className="underline group-hover:text-stone-700">Click to unfold copy details →</span>
                          </div>
                        )}

                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-auto pt-8 flex items-center justify-between border-t border-stone-100 text-[10px] text-stone-400 font-mono uppercase">
              <span>ALCO Library persistent storage initialized fully</span>
              <span>Local Session secure</span>
            </div>
          </div>
        )}

      </main>

      {/* Slide-out Panel Drawer (Active only when a Calendar item is selected - represents Step 7 Daily post workspace) */}
      <AnimatePresence>
        {selectedCalendarItemId && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.35 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedCalendarItemId(null)}
              className="fixed inset-0 bg-slate-950 z-40 cursor-pointer backdrop-blur-[1px]"
            />

            {/* Sidebar drawer panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.25 }}
              className="fixed right-0 top-0 bottom-0 z-40 w-full xs:max-w-md sm:max-w-lg md:max-w-xl bg-white shadow-2xl border-l border-slate-200 flex flex-col overflow-hidden"
            >
              
              {/* Drawer Header */}
              <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Megaphone size={16} className="text-blue-600 animate-pulse" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase">Daily Copywriter Workspace</h3>
                    <p className="text-[10px] text-slate-400 font-mono">STEP 7 • AI Daily Content Generation</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedCalendarItemId(null)}
                  className="p-1 px-2 text-slate-500 hover:text-slate-900 bg-slate-200/50 hover:bg-slate-200 rounded text-xs tracking-tight transition duration-150"
                >
                  <X size={15} />
                </button>
              </div>

              {/* Drawer Content block */}
              <div className="flex-1 overflow-y-auto p-5 space-y-6">
                
                {/* Information of Selected item */}
                {(() => {
                  const item = generatedCalendar.find(i => i.id === selectedCalendarItemId);
                  if (!item) return null;
                  return (
                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] uppercase font-mono font-bold bg-blue-600 text-white px-2 py-0.5 rounded shadow-sm">
                          DAY {item.dayIndex}
                        </span>
                        <span className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.5 rounded border ${getStageBadge(item.funnelStage)}`}>
                          {item.funnelStage}
                        </span>
                        <span className="text-[9px] uppercase font-mono font-bold bg-white text-slate-650 border border-slate-200 px-1.5 rounded">
                          {item.contentFormat}
                        </span>
                      </div>
                      <h4 className="text-xs font-mono uppercase tracking-tight text-slate-400 font-semibold pt-1">Topic details:</h4>
                      <p className="text-sm font-semibold text-slate-900 leading-snug">
                        {item.topic}
                      </p>
                    </div>
                  );
                })()}

                {/* Loading status or data output */}
                {isGeneratingDaily ? (
                  <div className="py-20 text-center space-y-3 font-mono">
                    <RefreshCcw size={28} className="animate-spin text-blue-500 mx-auto" />
                    <div className="text-xs text-slate-700 tracking-wider font-semibold">Writing premium copy matching brand voice...</div>
                    <p className="text-[10px] text-slate-400 max-w-xs mx-auto">
                      Our copywriting engine is synthesizing your positioning anchors and guidelines with structured Gemini models.
                    </p>
                  </div>
                ) : activeDailyDetails ? (
                  <div className="space-y-5 animate-fadeIn">
                    
                    {/* Caption / Output post copying */}
                    <div className="bg-slate-50 rounded-lg p-4 bg-slate-50 border border-slate-200 space-y-2.5">
                      <div className="flex items-center justify-between border-b pb-1.5 border-slate-100">
                        <span className="text-[10px] uppercase font-mono font-bold text-slate-400 shadow-sm bg-white border border-slate-205 px-2 py-0.5 rounded">Ready Social Copy:</span>
                        <button
                          onClick={() => copyTextToClipboard(activeDailyDetails.caption, "Social Caption")}
                          className="flex items-center gap-1.5 text-[10px] px-2.5 py-1 bg-white hover:bg-slate-50 rounded border border-slate-200 text-blue-600 font-semibold transition duration-155 shadow-sm"
                        >
                          <Copy size={11} />
                          {copiedTextState === "Social Caption" ? "Copied!" : "Copy Caption"}
                        </button>
                      </div>

                      <p className="text-xs text-slate-800 whitespace-pre-line leading-relaxed font-mono font-medium bg-white p-3.5 rounded border border-slate-200 select-all shadow-inner">
                        {activeDailyDetails.caption}
                      </p>
                    </div>

                    {/* Step 7 variables details list */}
                    <div className="space-y-4">
                      
                      {/* Detailed hook and messaging indicators */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 font-mono">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block mb-1">Scrolling Hook:</span>
                          <p className="text-slate-700 leading-relaxed italic">&quot;{activeDailyDetails.hook}&quot;</p>
                        </div>
                        <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 font-mono">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block mb-1">Core Action CTA:</span>
                          <p className="text-blue-600 font-bold leading-relaxed">{activeDailyDetails.cta}</p>
                        </div>
                      </div>

                      <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 font-mono text-xs">
                        <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block mb-1">Target Post Objective:</span>
                        <p className="text-slate-700 leading-relaxed font-bold">{activeDailyDetails.contentObjective}</p>
                      </div>

                      {/* Creative Art brief */}
                      <div className="p-4 rounded-lg border border-dashed border-slate-300 bg-slate-50 space-y-3 text-xs font-mono">
                        <div className="font-semibold text-slate-800 border-b pb-1.5 border-dashed border-slate-200 tracking-tight uppercase flex items-center gap-1 text-[11px]">
                          <PlusCircle size={12} className="text-blue-600" />
                          Creative Design Brief
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Aesthetic Visual Direction:</span>
                          <p className="text-slate-700 mt-0.5 leading-relaxed italic">&quot;{activeDailyDetails.visualDirection}&quot;</p>
                        </div>

                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Technical Structure & Slider layout:</span>
                          <p className="text-slate-700 mt-0.5 leading-relaxed">{activeDailyDetails.designBrief}</p>
                        </div>

                        {/* Midjourney/Dall-e Prompt */}
                        <div className="bg-white p-3 border border-slate-200 rounded space-y-1 shadow-sm">
                          <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider flex items-center justify-between">
                            AI Image Generator Prompt:
                            <button
                              onClick={() => copyTextToClipboard(activeDailyDetails.imagePrompt, "Image Prompt")}
                              className="text-blue-600 hover:text-blue-750 underline"
                            >
                              Copy Prompt
                            </button>
                          </span>
                          <p className="text-slate-500 italic leading-snug mt-1">{activeDailyDetails.imagePrompt}</p>
                        </div>
                      </div>

                    </div>

                    {/* Step 8 Content Library Syncing Controls */}
                    <div className="pt-4 border-t border-slate-100">
                      <span className="text-[11px] font-mono text-slate-400 uppercase block mb-2 font-bold tracking-wider">
                        STEP 8 • Archive Asset to Content Library
                      </span>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5 font-mono">
                        {(["Draft", "Approved", "Scheduled", "Published"] as const).map(status => (
                          <button
                            key={status}
                            onClick={() => handleSaveToLibrary(status)}
                            className="bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-[10px] uppercase font-bold tracking-tight shadow-sm transition duration-150"
                          >
                            + Save {status}
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="py-12 text-center text-xs text-slate-400 font-mono">
                    Select any day schedule to load or generate daily write-ups.
                  </div>
                )}

              </div>

              {/* Drawer footer status */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 text-center font-mono text-[10px] text-slate-400 font-semibold">
                🔒 System secured. Edits are handled fully client-side.
              </div>

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Editing Dialog Modal pop */}
      <AnimatePresence>
        {editingCalendarItem && (
          <>
            {/* Overlay */}
            <div 
              onClick={() => setEditingCalendarItem(null)} 
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-[1px] z-50 transition-opacity cursor-pointer" 
            />

            {/* Dialog contents */}
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-xl border border-slate-200 w-full max-w-lg p-5 shadow-2xl overflow-hidden font-mono text-xs"
              >
                <div className="flex items-center justify-between border-b pb-3.5 mb-4 border-slate-100">
                  <h3 className="text-xs uppercase font-bold text-slate-800 flex items-center gap-1.5">
                    <Sliders size={13} className="text-blue-600" />
                    Modify Day {editingCalendarItem.dayIndex} Content Details
                  </h3>
                  <button onClick={() => setEditingCalendarItem(null)} className="text-slate-400 hover:text-slate-900">
                    <X size={15} />
                  </button>
                </div>

                <div className="space-y-4">
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] uppercase text-slate-400 mb-1.5 font-semibold">Funnel Segment</label>
                      <select
                        value={editingCalendarItem.funnelStage}
                        onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, funnelStage: e.target.value as any })}
                        className="w-full bg-slate-50 border border-slate-200 rounded p-2 text-slate-805"
                      >
                        <option value="TOFU">TOFU (Top of Funnel)</option>
                        <option value="MOFU">MOFU (Middle of Funnel)</option>
                        <option value="BOFU">BOFU (Bottom of Funnel)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase text-slate-400 mb-1.5 font-semibold">Content Format</label>
                      <select
                        value={editingCalendarItem.contentFormat}
                        onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, contentFormat: e.target.value as any })}
                        className="w-full bg-slate-50 border border-slate-200 rounded p-2 text-slate-805"
                      >
                        <option value="Single Image">Single Image</option>
                        <option value="Carousel">Carousel Slider</option>
                        <option value="Reel">Reel / Video</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-slate-400 mb-1.5 font-bold">Topic Name / Hook Core</label>
                    <textarea
                      value={editingCalendarItem.topic}
                      onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, topic: e.target.value })}
                      rows={2}
                      className="w-full bg-slate-50 border border-slate-200 rounded p-2 text-[11px] leading-snug font-sans font-medium text-slate-800 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-slate-400 mb-1.5 font-bold">First Line Scrolling Hook</label>
                    <input
                      type="text"
                      value={editingCalendarItem.hook}
                      onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, hook: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded p-2 font-mono text-slate-805 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-slate-400 mb-1.5 font-bold">Tactical Action CTA</label>
                    <input
                      type="text"
                      value={editingCalendarItem.cta}
                      onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, cta: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded p-2 font-mono text-slate-805 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase text-slate-400 mb-1.5">Direct Campaign Goal</label>
                    <input
                      type="text"
                      value={editingCalendarItem.contentObjective}
                      onChange={(e) => setEditingCalendarItem({ ...editingCalendarItem, contentObjective: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded p-2 text-slate-805 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                </div>

                <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 mt-4">
                  <button
                    onClick={() => setEditingCalendarItem(null)}
                    className="bg-slate-100 hover:bg-slate-200 p-2 px-3 rounded text-slate-600 font-semibold transition duration-150"
                  >
                    Cancel Action
                  </button>
                  <button
                    onClick={handleSaveEditedItem}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-2 px-4 rounded font-bold transition duration-150"
                  >
                    Save Modifications
                  </button>
                </div>
              </motion.div>
            </div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
