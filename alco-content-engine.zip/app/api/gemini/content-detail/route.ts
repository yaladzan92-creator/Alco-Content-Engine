import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { calendarItem, brandContext } = await req.json();

    if (!calendarItem || !brandContext) {
      return NextResponse.json({ error: "Calendar item and brand context are required." }, { status: 400 });
    }

    const brandName = brandContext.brandName || "Our Brand";
    const voice = brandContext.brandIdentity?.voice || "neutral";
    const tone = brandContext.brandIdentity?.tone || "informative";
    const values = brandContext.brandIdentity?.values?.join(", ") || "";
    const audienceStr = JSON.stringify(brandContext.audience || {});
    const offersStr = JSON.stringify(brandContext.offers || []);
    const brandRules = JSON.stringify(brandContext.brandRules || {});

    const itemStr = JSON.stringify(calendarItem);

    const prompt = `You are a world-class Copywriter and Art Director at the ALCO Intelligence Core.
Your duty is to inflate a single calendar bullet point into a rich, ready-to-publish social asset that adheres 100% to the brand strategy of "${brandName}".

--- SELECTED CALENDAR TARGET EVENT ---
${itemStr}

--- BRAND IDENTITY & VOICE GUIDELINES ---
- Voice: ${voice} (Must shine clearly throughout the copy)
- Tone: ${tone}
- Brand Values: ${values}
- Core Audience Profiles: ${audienceStr}
- Current Value Offers: ${offersStr}
- Creative Messaging & Guardrail Guidelines: ${brandRules}

--- GENERATION GUIDELINES & DIRECTIVES ---
1. "Hook": Re-forge the scrolling hook to be irresistible, respecting the brand rules.
2. "Caption": Draft the complete social media caption. Include formatted line breaks, bulleted conceptual breakdowns, natural spacing, and an appropriate amount of clean, intentional hashtags. Ensure it sounds authentic, deeply empathetic to freelance or founder pain points (depending on audience), and represents a genuine helper — never look like generic AI scrap.
3. "Main Message": State the one raw core takeaway that the system guarantees the reader learns.
4. "Visual Direction" & "Design Brief": Define precise instructions for the human designer (style, typographic hierarchy, colors to use, layout proportions).
5. "Image Prompt": Compose a highly descriptive visual prompt suitable for generating a matching background or flat design mockup illustration using premium stock or modern styled graphics (minimalist, 3D clay, retro tech, crisp flat vector, or authentic professional imagery). Keep it free of complex overlaid text, spelling blocks, or disfigured characters.

Please create this content detail in structured JSON with pristine detail.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are the master Art Director of ALCO Content Engine. You generate highly integrated, complete, publishable marketing assets with zero placeholders.`,
        temperature: 0.4,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          description: "Full content bundle assets generated for a selected social media output.",
          properties: {
            contentObjective: {
              type: Type.STRING,
              description: "The concrete marketing goal of this specific post (e.g. solve onboarding issue, explain write-off benefit)."
            },
            hook: {
              type: Type.STRING,
              description: "The elevated high-impact first line hook."
            },
            mainMessage: {
              type: Type.STRING,
              description: "The primary psychological message or learning of this post."
            },
            caption: {
              type: Type.STRING,
              description: "The full length social copy ready for publication (LinkedIn, Instagram, post, etc.) with clean line-breaks."
            },
            cta: {
              type: Type.STRING,
              description: "Clear and urgent Call to Action promoting one of our offers."
            },
            visualDirection: {
              type: Type.STRING,
              description: "Sensory art direction specifying general aesthetic style, lighting, color palettes, and emotional feeling."
            },
            designBrief: {
              type: Type.STRING,
              description: "Technical structure briefs for graphic and video layouts (carousels order, reel text overlay hooks, text-safe margins)."
            },
            imagePrompt: {
              type: Type.STRING,
              description: "A tailored descriptive prompt for a high-quality visual generator."
            }
          },
          required: ["contentObjective", "hook", "mainMessage", "caption", "cta", "visualDirection", "designBrief", "imagePrompt"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from content asset generator.");
    }

    const details = JSON.parse(text);
    return NextResponse.json({ details });
  } catch (error: any) {
    console.error("AI Daily Content Detail Generation Error:", error);
    return NextResponse.json({ error: error.message || "Failed to generate daily content detail asset." }, { status: 500 });
  }
}
