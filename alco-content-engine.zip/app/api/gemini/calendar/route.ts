import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { brandContext, durationDays, objective } = await req.json();

    if (!brandContext) {
      return NextResponse.json({ error: "Brand context is required." }, { status: 400 });
    }

    const days = parseInt(durationDays) || 7;

    const brandName = brandContext.brandName || "Our Brand";
    const voice = brandContext.brandIdentity?.voice || "neutral";
    const tone = brandContext.brandIdentity?.tone || "informative";
    const corePromise = brandContext.positioning?.corePromise || "";
    const audienceStr = JSON.stringify(brandContext.audience || {});
    const messagingStr = JSON.stringify(brandContext.messaging || {});
    const rulesStr = JSON.stringify(brandContext.brandRules || {});
    const strategyStr = JSON.stringify(brandContext.contentStrategy || {});

    // Design-enforced distribution calculations
    const tofuCount = Math.max(1, Math.round(days * 0.40));
    const mofuCount = Math.max(1, Math.round(days * 0.35));
    const bofuCount = Math.max(1, days - tofuCount - mofuCount);

    const prompt = `You are a high-level marketing strategist and expert copywriter generating a fully integrated, brand-aware Content Calendar plan for "${brandName}".

Your goal is to generate a logical ${days}-day marketing plan targeting the objective: "${objective}".
This content system MUST have exactly:
- ${tofuCount} Top-Of-Funnel (TOFU) items (focused on education, broad pain points, high-shareability)
- ${mofuCount} Middle-Of-Funnel (MOFU) items (focused on brand trust, proprietary framework alignment, deep interest)
- ${bofuCount} Bottom-Of-Funnel (BOFU) items (focused on direct purchase triggers, case audits, specific offers and direct conversions)

--- BRAND STRATEGY DOSSIER (Source of Truth) ---
- Core Promise: ${corePromise}
- Audience Demographics, Pain Points & Desires: ${audienceStr}
- Core Messaging Gears: ${messagingStr}
- Creative Angles and Channels: ${strategyStr}
- Styling and Messaging Rules: ${rulesStr}

--- CONTENT CALENDAR RULES ---
1. You MUST generate exactly ${days} sequential content calendar items (indexed 1 to ${days}).
2. Choose logical content formats ('Single Image', 'Carousel', or 'Reel') that fit each funnel stage and objective.
3. Every idea must strictly utilize the conversational hooks, preferred channels, and angles from the Strategy Doss dossier.
4. Keep Hook and CTA lines brief, snappy, highly conversational, and formatted matching the brand Voice (${voice}) and Tone (${tone}).
5. Strictly adhere to the brand Rules: Do NOT use prohibited jargon, clickbait, or style restrictions listed in the dontRules. Only use active, direct verbs.

Generate exactly ${days} ledger logs for this campaign, each detailing: the day, funnel stage, specific content objective, content format, topic name, hook line, and strategic Call-to-Action (CTA).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the premium brand strategist AI core of ALCO Marketing. You output structured JSON campaigns that map perfectly to marketing calendars, guaranteeing voice consistency.",
        temperature: 0.3,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          description: "List of chronologically ordered content calendar entries for the branding sprint.",
          items: {
            type: Type.OBJECT,
            properties: {
              dayIndex: {
                type: Type.INTEGER,
                description: "The calendar day index (starting at 1)."
              },
              funnelStage: {
                type: Type.STRING,
                description: "The conversion funnel segment: 'TOFU', 'MOFU', or 'BOFU'."
              },
              contentObjective: {
                type: Type.STRING,
                description: "Tactical objective for this specific post."
              },
              contentFormat: {
                type: Type.STRING,
                description: "Visual packaging style: 'Single Image', 'Carousel', or 'Reel'."
              },
              topic: {
                type: Type.STRING,
                description: "Topic description or core story concept (specifically aligned with brand messaging pillars)."
              },
              hook: {
                type: Type.STRING,
                description: "High-voltage first sentence/hook designed to capture reader scrolling."
              },
              cta: {
                type: Type.STRING,
                description: "Specific action line guiding user to offers."
              }
            },
            required: ["dayIndex", "funnelStage", "contentObjective", "contentFormat", "topic", "hook", "cta"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from content calendar generation.");
    }

    const calendar = JSON.parse(text);
    return NextResponse.json({ calendar });
  } catch (error: any) {
    console.error("AI Calendar Generation Error:", error);
    return NextResponse.json({ error: error.message || "Failed to generate content calendar." }, { status: 500 });
  }
}
