"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { 
  Database, 
  UploadCloud, 
  FileJson, 
  FileText, 
  Cpu, 
  CheckCircle, 
  AlertTriangle, 
  Save, 
  Sliders, 
  Key, 
  Layers, 
  ArrowLeft, 
  ArrowRight, 
  RefreshCcw, 
  Sparkles, 
  Lock, 
  Unlock, 
  Check, 
  Plus, 
  Trash2,
  ListChecks,
  Activity
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface BrandContextType {
  brandName: string;
  brandIdentity: {
    voice: string;
    tone: string;
    mission: string;
    values: string[];
  };
  audience: {
    segments: string[];
    painPoints: string[];
    desires: string[];
  };
  positioning: {
    corePromise: string;
    tagline: string;
    differentiation: string[];
  };
  offers: {
    name: string;
    benefits: string[];
    price: string;
    ctaText: string;
  }[];
  messaging: {
    keyPillars: string[];
    elevatorPitch: string;
    conversationalHooks: string[];
  };
  contentStrategy: {
    pillars: string[];
    preferredChannels: string[];
    angles: string[];
  };
  brandRules: {
    doRules: string[];
    dontRules: string[];
  };
}

const TEMPLATE_JSON = {
  nicheData: {
    brandName: "Aura Glow Skin",
    niche: "Premium Organic Skincare",
    mission: "Membantu wanita urban mendapatkan kulit sehat bercahaya alami secara aman."
  },
  audienceData: {
    segments: ["Wanita karir usia 25-40 tahun", "Ibu muda peduli kesehatan kulit alami"],
    painPoints: ["Kulit kusam akibat polusi & stres", "Khawatir efek samping bahan kimia keras"],
    desires: ["Kulit wajah kenyal, glowing sehat", "Solusi skincare organik praktis & aman"]
  },
  positioningData: {
    corePromise: "100% Organik, Hasil Nyata Bercahaya Sehat dalam 14 Hari.",
    tagline: "Cantik Alami dari Alam",
    differentiation: ["Menggunakan konsentrat murni bunga teratai salju", "Tanpa pewarna, tanpa pewangi buas, vegan-friendly"]
  },
  offerData: {
    name: "Aura Glow Ultimate Set",
    benefits: ["Mendapatkan Essential Toner, Daily Cream, dan Hydra Serum", "Konsultasi eksklusif gratis dengan ahli kecantikan"],
    price: "Rp 349.000",
    ctaText: "Mulai Cantik Organik Sekarang"
  },
  copyDirection: {
    voice: "Edukasi bersahabat, penuh perhatian, dan menenangkan",
    tone: "Menginspirasi, terpercaya, hangat",
    doRules: ["Fokus pada istilah 'Bercahaya Sehat'", "Cantumkan sertifikat keorganikan produk"],
    dontRules: ["Jangan janji yang berlebihan / overclaiming", "Jangan kritik kompetitor secara langsung"]
  }
};

const getCleanBaseUrl = (inputUrl: string) => {
  let clean = inputUrl.trim();
  clean = clean.replace(/\/+$/, "");
  if (clean.endsWith("/api/health")) {
    clean = clean.substring(0, clean.length - 11).replace(/\/+$/, "");
  } else if (clean.endsWith("/api")) {
    clean = clean.substring(0, clean.length - 4).replace(/\/+$/, "");
  } else if (clean.endsWith("/health")) {
    clean = clean.substring(0, clean.length - 7).replace(/\/+$/, "");
  }
  return clean;
};

export default function DataSourceManagerPage() {
  const [activeMenuTab, setActiveMenuTab] = useState<"import-json" | "paste-json" | "api-pro" | "preview">("import-json");
  
  // App context sync states
  const [activeDossier, setActiveDossier] = useState<BrandContextType | null>(null);
  const [rawManualJson, setRawManualJson] = useState<string>("");
  const [pasteValue, setPasteValue] = useState<string>("");
  const [jsonImportError, setJsonImportError] = useState<string | null>(null);
  
  // Connection states
  const [apiBaseUrl, setApiBaseUrl] = useState<string>("");
  const [apiToken, setApiToken] = useState<string>("");
  const [apiConnStatus, setApiConnStatus] = useState<"disconnected" | "testing" | "active" | "failed">("disconnected");
  
  // User Premium state
  const [proUnlocked, setProUnlocked] = useState<boolean>(false);
  const [licenseKeyInput, setLicenseKeyInput] = useState<string>("");
  const [proLicenseError, setProLicenseError] = useState<string | null>(null);
  
  // Synchronization metadata
  const [dataSourceMode, setDataSourceMode] = useState<"Manual Import" | "API Sync">("Manual Import");
  const [lastUpdated, setLastUpdated] = useState<string>("Belum Diimpor");
  const [projectName, setProjectName] = useState<string>("Sandbox Campaign Blueprint");
  const [dragActive, setDragActive] = useState<boolean>(false);
  
  // Context editing fields (Preview panel)
  const [editingFieldPath, setEditingFieldPath] = useState<string | null>(null);
  const [tempEditorValue, setTempEditorValue] = useState<string>("");

  const [notification, setNotification] = useState<{message: string; type: "success" | "error" | "info"} | null>(null);

  const triggerNotification = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Convert manual structure into campaign-compliant BrandContextType structure
  const convertToBrandContext = (manual: any): BrandContextType => {
    const brandName = manual.nicheData?.brandName || manual.positioningData?.brandName || "Brand Baru";
    return {
      brandName: brandName,
      brandIdentity: {
        voice: manual.copyDirection?.voice || manual.copyDirection?.brandVoice || "Professional",
        tone: manual.copyDirection?.tone || manual.copyDirection?.brandTone || "Warm, Friendly",
        mission: manual.nicheData?.mission || manual.nicheData?.niche || "",
        values: manual.copyDirection?.doRules?.slice(0, 3) || manual.positioningData?.differentiation || []
      },
      audience: {
        segments: manual.audienceData?.segments || [],
        painPoints: manual.audienceData?.painPoints || [],
        desires: manual.audienceData?.desires || []
      },
      positioning: {
        corePromise: manual.positioningData?.corePromise || "",
        tagline: manual.positioningData?.tagline || "",
        differentiation: manual.positioningData?.differentiation || []
      },
      offers: [
        {
          name: manual.offerData?.name || manual.offerData?.offerName || "Standard Offer",
          benefits: manual.offerData?.benefits || [],
          price: manual.offerData?.price || "Rp 0",
          ctaText: manual.offerData?.ctaText || "Beli Sekarang"
        }
      ],
      messaging: {
        keyPillars: manual.positioningData?.differentiation || [],
        elevatorPitch: manual.nicheData?.mission || "",
        conversationalHooks: manual.audienceData?.painPoints || []
      },
      contentStrategy: {
        pillars: manual.copyDirection?.doRules || [],
        preferredChannels: ["Instagram", "WhatsApp", "Tiktok"],
        angles: manual.audienceData?.desires || []
      },
      brandRules: {
        doRules: manual.copyDirection?.doRules || [],
        dontRules: manual.copyDirection?.dontRules || []
      }
    };
  };

  // Check Data Health
  const calculateDataHealth = (manual: any) => {
    if (!manual) return { status: "KOSONG / BELUM ADA DATA", missing: ["Semua Bagian"] };
    const missing: string[] = [];
    if (!manual.nicheData) missing.push("nicheData");
    if (!manual.audienceData) missing.push("audienceData");
    if (!manual.positioningData) missing.push("positioningData");
    if (!manual.offerData) missing.push("offerData");
    if (!manual.copyDirection) missing.push("copyDirection");

    // Sub-fields checks
    if (manual.nicheData && !manual.nicheData.brandName) missing.push("nicheData.brandName");
    if (manual.nicheData && !manual.nicheData.mission) missing.push("nicheData.mission");
    if (manual.audienceData && (!manual.audienceData.segments || manual.audienceData.segments.length === 0)) missing.push("audienceData.segments");
    if (manual.positioningData && !manual.positioningData.corePromise) missing.push("positioningData.corePromise");
    if (manual.offerData && !manual.offerData.name) missing.push("offerData.name");

    if (missing.length === 0) {
      return { status: "KAPABILITAS LENGKAP (COMPLETE)", color: "text-emerald-600 bg-emerald-50 border-emerald-200", isOk: true, missing: [] };
    }
    return { 
      status: `BELUM LENGKAP (${missing.length} Item Hilang/Kosong)`, 
      color: "text-amber-600 bg-amber-50 border-amber-200", 
      isOk: false, 
      missing 
    };
  };

  // Mount logic
  useEffect(() => {
    if (typeof window !== "undefined") {
      // 1. Load active campaign context
      const savedDossierJson = window.localStorage.getItem("alco_imported_dossier");
      let parsedDossier: BrandContextType | null = null;
      let initProjectName = "Sandbox Campaign Blueprint";
      if (savedDossierJson) {
        try {
          parsedDossier = JSON.parse(savedDossierJson);
          initProjectName = parsedDossier?.brandName || "Active Project";
        } catch (_) {}
      }

      // 2. Load raw manual data sources
      const savedManualRaw = window.localStorage.getItem("alco_manual_data_raw") || "";

      // 3. Load pro states
      const savedProUnlocked = window.localStorage.getItem("alco_pro_unlocked") === "true";

      // 4. Load API credentials
      const savedUrl = window.localStorage.getItem("alco_api_url") || "";
      const savedKey = window.localStorage.getItem("alco_api_key") || "";

      // 5. Load source mode metadata
      const savedSourceMode = window.localStorage.getItem("alco_data_source_mode") as "Manual Import" | "API Sync" || "Manual Import";

      // 6. Load update date
      const savedDate = window.localStorage.getItem("alco_data_source_last_updated") || "Belum Diimpor / Default";

      // Defer all states to next tick to resolve rendering cascades warning
      setTimeout(() => {
        if (parsedDossier) {
          setActiveDossier(parsedDossier);
        }
        setProjectName(initProjectName);
        if (savedManualRaw) {
          setRawManualJson(savedManualRaw);
          setPasteValue(savedManualRaw);
        }
        setProUnlocked(savedProUnlocked);
        setApiBaseUrl(savedUrl);
        setApiToken(savedKey);
        setDataSourceMode(savedSourceMode);
        setLastUpdated(savedDate);
      }, 0);
    }
  }, []);

  const handleUpdateStorage = (
    updatedDossier: BrandContextType, 
    rawJsonStr: string, 
    mode: "Manual Import" | "API Sync"
  ) => {
    const timestamp = new Date().toLocaleString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });

    window.localStorage.setItem("alco_imported_dossier", JSON.stringify(updatedDossier));
    window.localStorage.setItem("alco_manual_data_raw", rawJsonStr);
    window.localStorage.setItem("alco_data_source_mode", mode);
    window.localStorage.setItem("alco_data_source_last_updated", timestamp);
    window.localStorage.setItem("alco_fallback_mode_active", "true");

    setActiveDossier(updatedDossier);
    setRawManualJson(rawJsonStr);
    setDataSourceMode(mode);
    setLastUpdated(timestamp);
    setProjectName(updatedDossier.brandName);
  };

  // Validate the 5 primary structures in inputted manual JSON
  const validateAndImportData = (rawText: string) => {
    try {
      setJsonImportError(null);
      const parsed = JSON.parse(rawText.trim());

      // Semantic validate
      const missingRoot: string[] = [];
      if (!parsed.nicheData) missingRoot.push("nicheData");
      if (!parsed.audienceData) missingRoot.push("audienceData");
      if (!parsed.positioningData) missingRoot.push("positioningData");
      if (!parsed.offerData) missingRoot.push("offerData");
      if (!parsed.copyDirection) missingRoot.push("copyDirection");

      if (missingRoot.length > 0) {
        throw new Error(`Kunci struktur utama wajib diisi: ${missingRoot.join(", ")}`);
      }

      // Succeeded validation processing
      const campaignDossier = convertToBrandContext(parsed);
      handleUpdateStorage(campaignDossier, JSON.stringify(parsed, null, 2), "Manual Import");
      triggerNotification("Rencana project import manual berhasil diimpor & disimpan!", "success");
      setActiveMenuTab("preview");
    } catch (err: any) {
      console.error(err);
      setJsonImportError(err.message || "Syntactical parser error. JSON tidak valid.");
      triggerNotification("Gagal memvalidasi/impor data JSON. Periksa format Anda.", "error");
    }
  };

  // Apply default template
  const loadDefaultPresetData = () => {
    const strTemplate = JSON.stringify(TEMPLATE_JSON, null, 2);
    setPasteValue(strTemplate);
    triggerNotification("Template standard terisi! Klik 'Validasi & Simpan' untuk menerapkan.", "info");
  };

  // File drag & Upload hooks
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type !== "application/json" && !file.name.endsWith(".json")) {
        setJsonImportError("Tipe berkas tidak didukung. Harap upload berkas berekstensi .json");
        return;
      }
      const reader = new FileReader();
      reader.onload = (evt) => {
        const text = evt.target?.result as string;
        validateAndImportData(text);
      };
      reader.readAsText(file);
    }
  };

  const handleManualUploadSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (evt) => {
        const text = evt.target?.result as string;
        validateAndImportData(text);
      };
      reader.readAsText(file);
    }
  };

  const handleUnlockPro = () => {
    setProLicenseError(null);
    if (licenseKeyInput.trim() === "alco_elite_pass_2026") {
      setProUnlocked(true);
      window.localStorage.setItem("alco_pro_unlocked", "true");
      triggerNotification("Akses premium PRO berhasil diaktifkan! ✨", "success");
    } else {
      setProLicenseError("Gagal: Kunci lisensi premium salah atau salah ketik.");
      triggerNotification("Kunci lisensi salah.", "error");
    }
  };

  const handleLockProAccess = () => {
    setProUnlocked(false);
    window.localStorage.setItem("alco_pro_unlocked", "false");
    triggerNotification("Lisensi PRO dinonaktifkan.", "info");
  };

  // Real-time server diagnostics health synchronisation
  const handleProSyncFetch = async () => {
    if (!apiBaseUrl || !apiToken) {
      triggerNotification("Alamat API URL & Token wajib diisi untuk melakukan sync PRO.", "error");
      return;
    }

    setApiConnStatus("testing");
    triggerNotification("Menghubungkan ke API Pro...", "info");

    const endpointDomain = getCleanBaseUrl(apiBaseUrl);
    const resolvedUrl = endpointDomain === "" ? "/api" : `${endpointDomain}/api`;
    const checkUrl = `${resolvedUrl}/health`;

    try {
      const headers = {
        "x-api-key": apiToken,
        "Content-Type": "application/json"
      };

      const healthRes = await fetch(checkUrl, { method: "GET", headers });
      if (!healthRes.ok) {
        throw new Error(`Authentication token refused (HTTP ${healthRes.status})`);
      }

      // Fetch dynamic brands from API
      const brandsUrl = `${resolvedUrl}/brands`;
      const brandRes = await fetch(brandsUrl, { headers });
      if (!brandRes.ok) {
        throw new Error(`Gagal memuat katalog brand: HTTP ${brandRes.status}`);
      }

      const brandList = await brandRes.json();
      if (brandList && brandList.length > 0) {
        const primaryBrand = brandList[0];
        
        // Fetch detailed brand context values
        const contextUrl = `${resolvedUrl}/context/content/${primaryBrand.id}`;
        const contextRes = await fetch(contextUrl, { headers });
        if (!contextRes.ok) {
          throw new Error(`Gagal meload brand context folder payload: HTTP ${contextRes.status}`);
        }

        const contextData = await contextRes.json();
        
        // Store synced parameters directly
        handleUpdateStorage(contextData, JSON.stringify(contextData, null, 2), "API Sync");
        setApiConnStatus("active");
        
        // Update credentials
        window.localStorage.setItem("alco_api_url", resolvedUrl);
        window.localStorage.setItem("alco_api_key", apiToken);
        window.localStorage.setItem("alco_fallback_mode_active", "false");

        triggerNotification(`Koneksi PRO Aktif! Data Brand '${contextData.brandName}' berhasil disinkronkan.`, "success");
        setActiveMenuTab("preview");
      } else {
        throw new Error("Koneksi berhasil, tetapi tidak ada model brand yang ditemukan di database.");
      }
    } catch (e: any) {
      console.error(e);
      setApiConnStatus("failed");
      triggerNotification(`Pro Sync Gagal: ${e.message}`, "error");
    }
  };

  // Live editing support in Project Context preview
  const handleEditInlineInitiate = (fieldPath: string, initialValue: string) => {
    setEditingFieldPath(fieldPath);
    setTempEditorValue(initialValue);
  };

  const handleSaveInlineEdit = () => {
    if (!activeDossier || !editingFieldPath) return;

    const cloned = JSON.parse(JSON.stringify(activeDossier));
    
    if (editingFieldPath === "brandName") {
      cloned.brandName = tempEditorValue;
    } else if (editingFieldPath === "voice") {
      cloned.brandIdentity.voice = tempEditorValue;
    } else if (editingFieldPath === "tone") {
      cloned.brandIdentity.tone = tempEditorValue;
    } else if (editingFieldPath === "mission") {
      cloned.brandIdentity.mission = tempEditorValue;
    } else if (editingFieldPath === "corePromise") {
      cloned.positioning.corePromise = tempEditorValue;
    } else if (editingFieldPath === "tagline") {
      cloned.positioning.tagline = tempEditorValue;
    } else if (editingFieldPath === "offerName") {
      if (cloned.offers && cloned.offers[0]) {
        cloned.offers[0].name = tempEditorValue;
      }
    } else if (editingFieldPath === "offerPrice") {
      if (cloned.offers && cloned.offers[0]) {
        cloned.offers[0].price = tempEditorValue;
      }
    }

    // Save
    handleUpdateStorage(cloned, rawManualJson, dataSourceMode);
    setEditingFieldPath(null);
    triggerNotification("Perubahan context berhasil disimpan!", "success");
  };

  // Parse structured details for Data Health Analysis
  let parsedRaw: any = null;
  try {
    if (rawManualJson) {
      parsedRaw = JSON.parse(rawManualJson);
    }
  } catch (_) {}

  const healthDetail = calculateDataHealth(parsedRaw);

  return (
    <div id="data-source-container" className="min-h-screen bg-slate-50/50 pb-20 text-slate-800">
      
      {/* Toast Notification Alert Banner */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 rounded-xl border shadow-lg font-medium text-xs tracking-tight ${
              notification.type === "success" 
                ? "bg-emerald-50 text-emerald-800 border-emerald-200" 
                : notification.type === "error" 
                ? "bg-red-50 text-red-800 border-red-200" 
                : "bg-blue-50 text-blue-800 border-blue-200"
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
            <p>{notification.message}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modern Header */}
      <header className="border-b border-slate-200/80 bg-white shadow-sm sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link 
              href="/" 
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 p-2.5 rounded-lg transition border border-slate-200 flex items-center justify-center"
              title="Kembali ke Dashboard"
            >
              <ArrowLeft size={16} />
            </Link>
            <div>
              <div className="flex items-center gap-2">
                <Database size={18} className="text-blue-600" />
                <h1 className="text-lg font-bold text-slate-900 tracking-tight uppercase font-sans">
                  Data Source Manager
                </h1>
                <span className="bg-slate-100 border border-slate-200 text-slate-500 font-mono text-[9px] px-2 py-0.5 rounded-md font-bold uppercase">
                  v2.2
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono">
                Atur model data referensi generator copywriting campaign Anda
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="bg-blue-600 hover:bg-blue-700 text-white border border-blue-700 px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 uppercase tracking-wide shadow-sm"
            >
              <Sliders size={13} />
              <span>Kembali Ke Planner</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 md:px-6 py-6 space-y-6">
        
        {/* TOP STATUS OVERVIEW RAILS PANEL */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-450 text-slate-400 font-bold">🎯 Source Mode</p>
            <div className="flex items-center justify-between">
              <p className="text-sm font-bold text-slate-800 font-sans flex items-center gap-1.5">
                <span className={`w-2.5 h-2.5 rounded-full ${dataSourceMode === "API Sync" ? "bg-blue-600 animate-pulse" : "bg-amber-500"}`} />
                {dataSourceMode === "API Sync" ? "API Sync (PRO)" : "Manual Import (FREE)"}
              </p>
              {dataSourceMode === "API Sync" ? (
                <span className="bg-blue-50 border border-blue-200 text-blue-600 font-extrabold text-[9px] px-2 py-0.5 rounded-md uppercase font-mono">PRO</span>
              ) : (
                <span className="bg-amber-50 border border-amber-200 text-amber-700 font-extrabold text-[9px] px-2 py-0.5 rounded-md uppercase font-mono">FREE</span>
              )}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-400 font-bold">⏱️ Last Updated</p>
            <p className="text-xs font-mono font-bold text-slate-800 leading-relaxed truncate" title={lastUpdated}>
              {lastUpdated}
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-400 font-bold">📁 Project Context Target</p>
            <p className="text-sm font-bold text-slate-800 font-sans truncate">
              ⚜️ {projectName || "Belum Ditentukan"}
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-1">
            <p className="text-[10px] uppercase font-mono text-slate-400 font-bold">🩺 Data Health Diagnostics</p>
            <div className="flex items-center gap-2">
              <span className={`text-[11px] px-2.5 py-1 rounded-md font-mono font-bold border ${healthDetail.isOk ? "bg-emerald-50 border-emerald-250 text-emerald-700" : "bg-amber-50 border-amber-250 text-amber-700 font-sans"}`}>
                {healthDetail.isOk ? "LENGKAP / SEHAT ✓" : "KURANG LENGKAP ⚠"}
              </span>
            </div>
          </div>

        </div>

        {/* MAIN SPLIT GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT SIDE NAVIGATION MENU CONTROLS - Lg-cols-4 */}
          <div className="lg:col-span-4 space-y-4">
            
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-1">
              <h3 className="text-xs font-extrabold text-slate-900 font-mono uppercase tracking-wider mb-3">
                Menu Pengaturan
              </h3>
              
              <div className="flex flex-col gap-1.5">
                <button
                  onClick={() => setActiveMenuTab("import-json")}
                  className={`w-full flex items-center justify-between text-left px-4 py-3 rounded-xl transition font-medium text-xs ${
                    activeMenuTab === "import-json"
                      ? "bg-blue-600 text-white shadow-sm font-bold"
                      : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <UploadCloud size={14} />
                    <span>Import File JSON</span>
                  </div>
                  <Check size={14} className={activeMenuTab === "import-json" ? "opacity-100" : "opacity-0"} />
                </button>

                <button
                  onClick={() => setActiveMenuTab("paste-json")}
                  className={`w-full flex items-center justify-between text-left px-4 py-3 rounded-xl transition font-medium text-xs ${
                    activeMenuTab === "paste-json"
                      ? "bg-blue-600 text-white shadow-sm font-bold"
                      : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <FileText size={14} />
                    <span>Paste Teks JSON</span>
                  </div>
                  <Check size={14} className={activeMenuTab === "paste-json" ? "opacity-100" : "opacity-0"} />
                </button>

                <button
                  onClick={() => setActiveMenuTab("api-pro")}
                  className={`w-full flex items-center justify-between text-left px-4 py-3 rounded-xl transition font-medium text-xs ${
                    activeMenuTab === "api-pro"
                      ? "bg-blue-600 text-white shadow-sm font-bold"
                      : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {proUnlocked ? <Cpu size={14} /> : <Lock size={14} className="text-amber-500" />}
                    <span className="flex items-center gap-1.5">
                      API Connection
                      <span className={`text-[8px] px-1 py-0.2 rounded font-sans font-bold uppercase border ${
                        activeMenuTab === "api-pro" 
                          ? "bg-blue-800 text-blue-100 border-blue-900" 
                          : "bg-blue-50 text-blue-600 border-blue-100"
                        }`}
                      >
                        PRO
                      </span>
                    </span>
                  </div>
                  {proUnlocked ? (
                    <span className="text-[9px] bg-emerald-500 text-white font-bold px-1.5 py-0.5 rounded">AKTIF</span>
                  ) : (
                    <Lock size={12} className="opacity-60" />
                  )}
                </button>

                <button
                  onClick={() => setActiveMenuTab("preview")}
                  className={`w-full flex items-center justify-between text-left px-4 py-3 rounded-xl transition font-medium text-xs ${
                    activeMenuTab === "preview"
                      ? "bg-blue-600 text-white shadow-sm font-bold"
                      : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Layers size={14} />
                    <span>Project Context Preview</span>
                  </div>
                  <Check size={14} className={activeMenuTab === "preview" ? "opacity-100" : "opacity-0"} />
                </button>
              </div>

            </div>

            {/* QUICK VALIDATION CARD REPORT */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase font-mono flex items-center gap-1.5">
                <Activity size={14} className="text-blue-500" />
                Laporan Integritas Kamus Data
              </h4>
              <div className="text-xs space-y-2 font-mono">
                <div className="flex justify-between items-center py-1 border-b border-slate-105-0.5 border-dashed border-slate-100">
                  <span className="text-slate-400">nicheData</span>
                  <span>{parsedRaw?.nicheData ? "✅ Terbaca" : "❌ Kosong"}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100 border-dashed">
                  <span className="text-slate-400">audienceData</span>
                  <span>{parsedRaw?.audienceData ? "✅ Terbaca" : "❌ Kosong"}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100 border-dashed">
                  <span className="text-slate-400">positioningData</span>
                  <span>{parsedRaw?.positioningData ? "✅ Terbaca" : "❌ Kosong"}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100 border-dashed">
                  <span className="text-slate-400">offerData</span>
                  <span>{parsedRaw?.offerData ? "✅ Terbaca" : "❌ Kosong"}</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-400">copyDirection</span>
                  <span>{parsedRaw?.copyDirection ? "✅ Terbaca" : "❌ Kosong"}</span>
                </div>
              </div>
              
              {!healthDetail.isOk && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 text-[11px] text-amber-800 font-medium space-y-1 leading-relaxed">
                  <p className="font-bold flex items-center gap-1">
                    <span>⚠️</span> Membutuhkan Perbaikan:
                  </p>
                  <ul className="list-disc pl-3.5 space-y-0.5 font-mono text-[10px]">
                    {healthDetail.missing.slice(0, 4).map((m, idx) => (
                      <li key={idx}>Missing: {m}</li>
                    ))}
                    {healthDetail.missing.length > 4 && (
                      <li>Dan {healthDetail.missing.length - 4} item lainnya...</li>
                    )}
                  </ul>
                </div>
              )}
            </div>

          </div>

          {/* RIGHT SIDE DETAILED WORKSPACE CONTENT - Lg-cols-8 */}
          <div className="lg:col-span-8">
            
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden min-h-[460px]">
              
              {/* Card headers based on sub-route selection */}
              <div className="bg-slate-50/50 border-b border-slate-200/80 px-6 py-4 flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider font-mono flex items-center gap-2">
                  {activeMenuTab === "import-json" && "Upload Dokumen (.json)"}
                  {activeMenuTab === "paste-json" && "Formulir Tempel Teks (Paste JSON / Custom)"}
                  {activeMenuTab === "api-pro" && "Koneksi Sinkronisasi App 1 (Premium)"}
                  {activeMenuTab === "preview" && "Visualisasi Model Project Context"}
                </h2>
                <span className="text-[10px] uppercase font-bold text-slate-400 font-mono">
                  {activeMenuTab}
                </span>
              </div>

              {/* Card contents */}
              <div className="p-6">
                
                {/* 1. IMPORT JSON FILE DROP */}
                {activeMenuTab === "import-json" && (
                  <div className="space-y-6">
                    <p className="text-xs text-slate-500 leading-relaxed font-mono">
                      Unggah berkas konfigurasi brand kustom berekstensi <code>.json</code> yang diekspor dari sistem Anda. 
                      Sistem kami akan membaca dan memprioritaskan struktur: <code>nicheData</code>, <code>audienceData</code>, <code>positioningData</code>, <code>offerData</code>, dan <code>copyDirection</code> secara otomatis.
                    </p>

                    <div
                      onDragEnter={handleDrag}
                      onDragOver={handleDrag}
                      onDragLeave={handleDrag}
                      onDrop={handleDrop}
                      className={`border-2 border-dashed rounded-2xl p-10 flex flex-col items-center justify-center text-center transition cursor-pointer min-h-[220px] ${
                        dragActive 
                          ? "bg-blue-50 border-blue-500 text-blue-900 shadow-inner" 
                          : "border-slate-200 hover:border-slate-350 hover:bg-slate-50/55"
                      }`}
                      onClick={() => {
                        const elem = document.getElementById("hidden-file-input");
                        if (elem) elem.click();
                      }}
                    >
                      <input 
                        type="file" 
                        id="hidden-file-input" 
                        accept="application/json" 
                        className="hidden" 
                        onChange={handleManualUploadSelect}
                      />
                      
                      <div className="bg-blue-50 text-blue-600 p-4 rounded-full mb-3.5 border border-blue-100">
                        <UploadCloud size={28} className={dragActive ? "animate-bounce" : ""} />
                      </div>

                      <p className="text-xs font-bold text-slate-800 uppercase tracking-tight">
                        Tarik & Lepas File Di Sini atau Klik Untuk Menjelajahi
                      </p>
                      
                      <p className="text-[10px] text-slate-400 font-mono mt-1">
                        Hanya mendukung berkas khusus berekstensi .JSON
                      </p>
                    </div>

                    {jsonImportError && (
                      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs text-red-900 flex items-start gap-2.5 leading-relaxed font-mono">
                        <AlertTriangle className="text-red-600 shrink-0 mt-0.5" size={15} />
                        <div>
                          <p className="font-bold">Kesalahan Struktur File JSON:</p>
                          <p className="text-[10.5px] mt-0.5">{jsonImportError}</p>
                        </div>
                      </div>
                    )}

                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                        <span>💡 Tip:</span>
                        <span>Dapatkan template dummy di menu Paste Teks jika Anda belum punya data</span>
                      </div>
                      
                      <button
                        onClick={() => setActiveMenuTab("paste-json")}
                        className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                      >
                        Gunakan Paste Teks 
                        <ArrowRight size={13} />
                      </button>
                    </div>
                  </div>
                )}

                {/* 2. PASTE JSON RAW TEXT TO CONFIG */}
                {activeMenuTab === "paste-json" && (
                  <div className="space-y-6">
                    <p className="text-xs text-slate-500 leading-relaxed font-mono">
                      Ketikkan atau tempel muatan teks JSON Anda secara manual ke kolom di bawah. 
                      Struktur model ini akan sepenuhnya menggantikan project context yang sedang aktif pada generator App 2.
                    </p>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-slate-400 font-semibold uppercase font-mono">Input Editor:</span>
                        <button
                          type="button"
                          onClick={loadDefaultPresetData}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 font-mono font-bold text-[10px] px-2.5 py-1 rounded-md transition flex items-center gap-1.5"
                        >
                          <Sparkles size={11} className="text-amber-500 animate-pulse" />
                          Gunakan Contoh Template Dummy
                        </button>
                      </div>
                      
                      <textarea
                        value={pasteValue}
                        onChange={(e) => setPasteValue(e.target.value)}
                        placeholder='{"nicheData": { "brandName": "Brand Saya" }, ...}'
                        rows={10}
                        className="w-full bg-slate-900 text-emerald-400 border border-slate-700 rounded-xl p-4 font-mono text-[11.5px] focus:outline-none focus:border-blue-500 placeholder-slate-700"
                      />
                    </div>

                    {jsonImportError && (
                      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs text-red-900 flex items-start gap-2.5 leading-relaxed font-mono">
                        <AlertTriangle className="text-red-500 shrink-0 mt-0.5" size={15} />
                        <div>
                          <p className="font-bold">Konfirmasi Kesalahan Parsing:</p>
                          <p className="text-[10.5px] mt-0.5">{jsonImportError}</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                      <button
                        onClick={() => setPasteValue("")}
                        className="bg-white hover:bg-slate-50 text-slate-500 px-4 py-2 border border-slate-250 rounded-lg text-xs font-bold transition font-mono"
                      >
                        BERSIHKAN
                      </button>
                      
                      <button
                        onClick={() => validateAndImportData(pasteValue)}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-lg text-xs transition flex items-center gap-2 uppercase tracking-wide shadow-sm"
                      >
                        <Save size={13} />
                        <span>Validasi & Simpan</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* 3. API BRIDGE PRO CONNECTOR */}
                {activeMenuTab === "api-pro" && (
                  <div className="space-y-6">
                    
                    {/* Locked Premium State Indicator */}
                    {!proUnlocked ? (
                      <div className="bg-amber-50/50 border border-amber-200 rounded-2xl p-6 text-center space-y-4">
                        <div className="mx-auto w-12 h-12 bg-amber-100 text-amber-500 border border-amber-200 rounded-full flex items-center justify-center">
                          <Lock size={20} className="animate-pulse" />
                        </div>
                        
                        <div className="space-y-2">
                          <h3 className="text-xs font-extrabold font-mono uppercase tracking-widest text-amber-800">
                            🔒 SINKRONISASI OTOMATIS API TERKUNCI (PRO ONLY)
                          </h3>
                          <p className="text-xs text-amber-700 max-w-md mx-auto leading-relaxed">
                            Hubungkan data instan real-time dari Core Intelligence App 1 secara langsung ke planner App 2. Silakan masukkan Lisensi Token Premium Anda di bawah:
                          </p>
                        </div>

                        <div className="max-w-xs mx-auto space-y-2">
                          <div className="relative">
                            <Key className="absolute left-3 top-2.5 text-slate-400" size={13} />
                            <input
                              type="password"
                              value={licenseKeyInput}
                              onChange={(e) => setLicenseKeyInput(e.target.value)}
                              placeholder="Kode lisensi: alco_elite_pass_2026"
                              className="w-full bg-white border border-slate-200 text-xs rounded-lg pl-8 pr-3 py-2 text-slate-850 focus:outline-none focus:border-slate-400 transition"
                            />
                          </div>

                          {proLicenseError && (
                            <p className="text-[10px] text-red-500 font-mono font-bold">{proLicenseError}</p>
                          )}

                          <button
                            onClick={handleUnlockPro}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-4 rounded-lg transition shadow-sm uppercase tracking-wider"
                          >
                            Buka Fitur Premium
                          </button>
                        </div>
                      </div>
                    ) : (
                      // UNLOCKED Premium syncing interface block
                      <div className="animate-fadeIn space-y-6">
                        
                        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between text-xs text-emerald-850">
                          <div className="flex items-center gap-2">
                            <Unlock className="text-emerald-500" size={15} />
                            <span className="font-bold uppercase font-mono tracking-wider">Akses Premium PRO Aktif</span>
                          </div>
                          <button
                            onClick={handleLockProAccess}
                            className="text-[9px] uppercase font-bold text-red-600 border border-red-200 hover:bg-red-50 bg-white px-2.5 py-1 rounded transition"
                          >
                            Matikan Pro
                          </button>
                        </div>

                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="block text-[10px] uppercase font-mono tracking-wide text-slate-500 font-bold">Base API Host URL:</label>
                              <input
                                type="text"
                                value={apiBaseUrl}
                                onChange={(e) => setApiBaseUrl(e.target.value)}
                                placeholder="https://alco-creative-system-486549138020.asia-southeast1.run.app"
                                className="w-full bg-slate-50 border border-slate-250 rounded-lg text-xs px-3 py-2 font-mono text-slate-800"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="block text-[10px] uppercase font-mono tracking-wide text-slate-500 font-bold">Access Token Key:</label>
                              <input
                                type="password"
                                value={apiToken}
                                onChange={(e) => setApiToken(e.target.value)}
                                placeholder="Kunci token rahasia x-api-key"
                                className="w-full bg-slate-50 border border-slate-250 rounded-lg text-xs px-3 py-2 font-mono text-slate-800"
                              />
                            </div>
                          </div>

                          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 text-[11px] text-slate-500 space-y-1 leading-relaxed">
                            <p className="font-bold text-slate-650 text-slate-600 flex items-center gap-1">
                              <span>⚜️</span> Alur Kerja Sinkronisasi Cloud:
                            </p>
                            <p>
                              Menekan tombol &quot;Tarik &amp; Sinkron Data&quot; akan menghubungi server, memverifikasi token API, dan menyinkronkan 
                              draf brand intelligence terbaru dari database cloud secara aman dan otomatis ke Project Context di memori browser Anda.
                            </p>
                          </div>

                          <div className="flex justify-between items-center pt-2">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-slate-400 font-mono uppercase">Status Koneksi Pro:</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded font-bold font-mono transition uppercase ${
                                apiConnStatus === "testing" ? "bg-amber-100 text-amber-700 animate-pulse" :
                                apiConnStatus === "active" ? "bg-emerald-100 text-emerald-700 border border-emerald-250" :
                                apiConnStatus === "failed" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-500"
                              }`}>
                                {apiConnStatus}
                              </span>
                            </div>

                            <button
                              onClick={handleProSyncFetch}
                              disabled={apiConnStatus === "testing"}
                              className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold text-xs py-2 px-5 rounded-lg transition flex items-center gap-2 uppercase tracking-wide shadow-sm"
                            >
                              <RefreshCcw size={13} className={apiConnStatus === "testing" ? "animate-spin" : ""} />
                              Tarik & Sync Data Instan
                            </button>
                          </div>

                        </div>

                      </div>
                    )}

                  </div>
                )}

                {/* 4. ACTIVE PROJECT CONTEXT PREVIEW & MANUAL EDIT CARDS */}
                {activeMenuTab === "preview" && (
                  <div className="space-y-6">
                    
                    {!activeDossier ? (
                      <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 text-center text-slate-400 space-y-2">
                        <FileJson className="mx-auto" size={24} />
                        <p className="text-xs font-mono">Belum ada project context yang aktif saat ini.</p>
                        <p className="text-[11px]">Silakan unggah dari berkas JSON Anda di tab menu &apos;Import JSON&apos; atau &apos;Paste JSON&apos; untuk memulai.</p>
                      </div>
                    ) : (
                      // Active layout visualization
                      <div className="animate-fadeIn space-y-6">
                        
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                          <div>
                            <p className="text-[10px] uppercase font-mono text-slate-400 font-bold">⚜️ Model Intelligence Aktif</p>
                            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-1.5 mt-0.5">
                              {activeDossier.brandName}
                            </h3>
                          </div>
                          
                          <span className="text-[10px] font-mono bg-blue-50 border border-blue-200 text-blue-700 px-2.5 py-1 rounded-md font-bold uppercase">
                            Project Ready ⚡
                          </span>
                        </div>

                        {/* Collapsible structure view */}
                        <div className="space-y-4">
                          
                          {/* Niche Data details inline form */}
                          <div className="bg-slate-50/50 rounded-xl border border-slate-200/80 p-4 space-y-3.5">
                            <div className="flex items-center justify-between border-b border-slate-200/50 pb-1.5">
                              <h4 className="text-xs font-bold text-slate-700 font-mono uppercase tracking-wider flex items-center gap-1">
                                <ListChecks size={13} className="text-slate-400" />
                                1. Informasi Niche & Identitas Brand
                              </h4>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Brand Name:</span>
                                {editingFieldPath === "brandName" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1 py-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span>{activeDossier.brandName}</span>
                                    <button onClick={() => handleEditInlineInitiate("brandName", activeDossier.brandName)} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>

                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Voice Archetype:</span>
                                {editingFieldPath === "voice" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1 py-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span>{activeDossier.brandIdentity?.voice || "N/A"}</span>
                                    <button onClick={() => handleEditInlineInitiate("voice", activeDossier.brandIdentity?.voice || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>

                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Tone Signature:</span>
                                {editingFieldPath === "tone" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1 py-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span>{activeDossier.brandIdentity?.tone || "N/A"}</span>
                                    <button onClick={() => handleEditInlineInitiate("tone", activeDossier.brandIdentity?.tone || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>

                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Mission Statement:</span>
                                {editingFieldPath === "mission" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1 py-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span className="truncate flex-1 pr-4">{activeDossier.brandIdentity?.mission || "N/A"}</span>
                                    <button onClick={() => handleEditInlineInitiate("mission", activeDossier.brandIdentity?.mission || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Audience & Positioning Parameters */}
                          <div className="bg-slate-50/50 rounded-xl border border-slate-200/80 p-4 space-y-3">
                            <h4 className="text-xs font-bold text-slate-700 font-mono uppercase tracking-wider flex items-center gap-1 border-b border-slate-200/50 pb-1.5">
                              <Database size={13} className="text-slate-400" />
                              2. Target Audience & Positioning
                            </h4>
                            
                            <div className="text-xs space-y-2.5 leading-relaxed font-mono">
                              <div>
                                <span className="text-[10px] text-slate-450 text-slate-400 font-bold uppercase block mb-1">Target Segments:</span>
                                <div className="flex flex-wrap gap-1.5">
                                  {activeDossier.audience?.segments?.map((seg, i) => (
                                    <span key={i} className="bg-blue-50 border border-blue-100 text-blue-700 text-[10px] px-2 py-0.5 rounded">
                                      {seg}
                                    </span>
                                  ))}
                                </div>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1.5">
                                <div className="space-y-1">
                                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Core Positioning Promise:</span>
                                  {editingFieldPath === "corePromise" ? (
                                    <div className="flex items-center gap-1">
                                      <input 
                                        type="text" 
                                        value={tempEditorValue} 
                                        onChange={(e) => setTempEditorValue(e.target.value)} 
                                        className="bg-white border rounded p-1 flex-1 text-slate-800 animate-fadeIn"
                                      />
                                      <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                      <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1 py-1">X</button>
                                    </div>
                                  ) : (
                                    <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                      <span className="truncate pr-4">{activeDossier.positioning?.corePromise || "N/A"}</span>
                                      <button onClick={() => handleEditInlineInitiate("corePromise", activeDossier.positioning?.corePromise || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                    </div>
                                  )}
                                </div>

                                <div className="space-y-1">
                                  <span className="text-[10px] text-slate-400 font-bold block uppercase">Brand Tagline:</span>
                                  {editingFieldPath === "tagline" ? (
                                    <div className="flex items-center gap-1">
                                      <input 
                                        type="text" 
                                        value={tempEditorValue} 
                                        onChange={(e) => setTempEditorValue(e.target.value)} 
                                        className="bg-white border rounded p-1 flex-1 text-slate-800"
                                      />
                                      <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                      <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-600 bg-white border rounded px-1.5">X</button>
                                    </div>
                                  ) : (
                                    <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                      <span>{activeDossier.positioning?.tagline || "N/A"}</span>
                                      <button onClick={() => handleEditInlineInitiate("tagline", activeDossier.positioning?.tagline || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Offer Data Fields */}
                          <div className="bg-slate-50/50 rounded-xl border border-slate-200/80 p-4 space-y-3">
                            <h4 className="text-xs font-bold text-slate-700 font-mono uppercase tracking-wider flex items-center gap-1 border-b border-slate-200/50 pb-1.5">
                              <span>🛍️</span> 3. Core Campaign Marketing Offer
                            </h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Offer Item Name:</span>
                                {editingFieldPath === "offerName" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-650 bg-white border rounded px-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span>{activeDossier.offers?.[0]?.name || "N/A"}</span>
                                    <button onClick={() => handleEditInlineInitiate("offerName", activeDossier.offers?.[0]?.name || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>

                              <div className="space-y-1">
                                <span className="text-[10px] text-slate-400 font-bold block uppercase">Price Point:</span>
                                {editingFieldPath === "offerPrice" ? (
                                  <div className="flex items-center gap-1">
                                    <input 
                                      type="text" 
                                      value={tempEditorValue} 
                                      onChange={(e) => setTempEditorValue(e.target.value)} 
                                      className="bg-white border rounded p-1 flex-1 text-slate-800"
                                    />
                                    <button onClick={handleSaveInlineEdit} className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-bold">Simpan</button>
                                    <button onClick={() => setEditingFieldPath(null)} className="text-[10px] text-slate-650 bg-white border rounded px-1">X</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded border border-slate-200/60 text-slate-800">
                                    <span className="font-bold text-blue-600">{activeDossier.offers?.[0]?.price || "N/A"}</span>
                                    <button onClick={() => handleEditInlineInitiate("offerPrice", activeDossier.offers?.[0]?.price || "")} className="text-[10px] text-blue-600 hover:underline">Edit</button>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                        </div>

                      </div>
                    )}

                  </div>
                )}

              </div>

            </div>

          </div>

        </div>

      </main>

    </div>
  );
}
