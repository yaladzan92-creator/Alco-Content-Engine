"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { 
  Globe, 
  Key, 
  Radio, 
  Wifi, 
  WifiOff, 
  ShieldAlert, 
  CheckCircle, 
  RefreshCcw, 
  FileJson, 
  ArrowLeft, 
  Activity, 
  Cpu, 
  Layers, 
  ListChecks, 
  Sliders, 
  Sparkles,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface DynamicBrand {
  id: string;
  name: string;
  desc: string;
}

interface DynamicProject {
  id: string;
  name: string;
  workspace: string;
}

interface ApiDiagnostics {
  apiUrl: string;
  healthUrl: string;
  status: string | number | null;
  responseBody: string | null;
  timestamp: string | null;
}

const getCleanBaseUrl = (inputUrl: string) => {
  let clean = inputUrl.trim();
  
  // Strip trailing slashes
  clean = clean.replace(/\/+$/, "");
  
  // Prevent duplicate suffixes
  if (clean.endsWith("/api/health")) {
    clean = clean.substring(0, clean.length - 11).replace(/\/+$/, "");
  } else if (clean.endsWith("/api")) {
    clean = clean.substring(0, clean.length - 4).replace(/\/+$/, "");
  } else if (clean.endsWith("/health")) {
    clean = clean.substring(0, clean.length - 7).replace(/\/+$/, "");
  }
  
  return clean;
};

export default function ApiConnectionPage() {
  const [apiBaseUrl, setApiBaseUrl] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return window.localStorage.getItem("alco_api_url") || "";
    }
    return "";
  });
  const [apiToken, setApiToken] = useState<string>(() => {
    if (typeof window !== "undefined") {
      return window.localStorage.getItem("alco_api_key") || "";
    }
    return "";
  });
  const [apiDiagnostics, setApiDiagnostics] = useState<ApiDiagnostics | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "testing" | "active" | "failed">("disconnected");
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [lastSync, setLastSync] = useState<string>("Never");
  const [schemaVersion, setSchemaVersion] = useState("v2.1.0");
  const [detectedBrandsCount, setDetectedBrandsCount] = useState(0);
  const [detectedProjectsCount, setDetectedProjectsCount] = useState(0);
  const [fallbackModeActive, setFallbackModeActive] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.localStorage.getItem("alco_fallback_mode_active") === "true";
    }
    return false;
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [jsonImportError, setJsonImportError] = useState<string | null>(null);
  const [pasteJsonText, setPasteJsonText] = useState("");
  const [notification, setNotification] = useState<{message: string; type: "success" | "error" | "info"} | null>(null);

  const triggerNotification = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  const executeActualHealthCheck = async (
    url: string, 
    key: string, 
    isRetry: boolean = false, 
    silent: boolean = false
  ) => {
    setIsConnecting(true);
    setConnectionStatus("testing");
    setConnectionError(null);
    setApiDiagnostics(null);
    
    if (!silent) {
      triggerNotification("Sedang memeriksa koneksi ke server...", "info");
    }

    const baseDomain = getCleanBaseUrl(url);
    const finalApiUrl = baseDomain === "" ? "/api" : `${baseDomain}/api`;
    const healthUrl = `${finalApiUrl}/health`;

    // 4. Logging before fetch (Requirement 4)
    console.log("Raw API URL:", url);
    console.log("Final Health URL:", healthUrl);

    // 5. If healthUrl is relative, report the cause (Requirement 5)
    if (healthUrl === "/api/health") {
      console.warn("[API CONNECTION CHECK]: healthUrl is relative '/api/health'. This fallback occurs because the input API URL was empty or resolved to root; wait for manual connection center entry or local preview initialization in /app/api-connection/page.tsx.");
    }

    try {
      const requestHeaders = {
        "x-api-key": key,
        "Content-Type": "application/json"
      };

      console.log("API URL:", healthUrl);
      console.log("API Key:", key?.substring(0, 8));
      console.log("Headers:", requestHeaders);

      const res = await fetch(healthUrl, {
        method: "GET",
        headers: requestHeaders
      });

      const text = await res.text();
      let parsedBody: any = null;
      try {
        parsedBody = JSON.parse(text);
      } catch (_) {
        parsedBody = text || "(Empty string)";
      }

      console.log("Final API URL:", finalApiUrl);
      console.log("Final Health URL:", healthUrl);
      console.log("Response Status:", res.status);
      console.log("Response Body:", text);

      const fetchedDiagnostics: ApiDiagnostics = {
        apiUrl: finalApiUrl,
        healthUrl: healthUrl,
        status: res.status,
        responseBody: typeof parsedBody === "object" ? JSON.stringify(parsedBody, null, 2) : String(parsedBody),
        timestamp: new Date().toLocaleTimeString("id-ID")
      };

      setApiDiagnostics(fetchedDiagnostics);

      if (!res.ok) {
        throw new Error(`Failed to connect. URL: ${healthUrl} Status: ${res.status}`);
      }

      if (typeof parsedBody === "string" && parsedBody.includes("<!DOCTYPE html>")) {
        throw new Error(`Endpoint returned HTML instead of JSON metadata.`);
      }

      const verifiedApiBase = finalApiUrl;
      const verifiedToken = key;

      // Load brands & projects
      const brandsUrl = `${verifiedApiBase}/brands`;
      const projectsUrl = `${verifiedApiBase}/projects`;

      const requestHeadersSync = {
        "x-api-key": verifiedToken,
        "Content-Type": "application/json"
      };

      console.log("API URL:", brandsUrl);
      console.log("API Key:", verifiedToken?.substring(0, 8));
      console.log("Headers:", requestHeadersSync);

      console.log("API URL:", projectsUrl);
      console.log("API Key:", verifiedToken?.substring(0, 8));
      console.log("Headers:", requestHeadersSync);

      const [brandsRes, projectsRes] = await Promise.all([
        fetch(brandsUrl, { headers: requestHeadersSync }),
        fetch(projectsUrl, { headers: requestHeadersSync })
      ]);

      if (!brandsRes.ok) throw new Error(`Brands endpoint failed (${brandsRes.status})`);
      if (!projectsRes.ok) throw new Error(`Projects endpoint failed (${projectsRes.status})`);

      const brandsData = await brandsRes.json();
      const projectsData = await projectsRes.json();

      // Save credentials.
      localStorage.setItem("alco_api_url", verifiedApiBase);
      localStorage.setItem("alco_api_key", verifiedToken);
      localStorage.setItem("alco_fallback_mode_active", "false");

      setApiBaseUrl(verifiedApiBase);
      setApiToken(verifiedToken);
      setConnectionStatus("active");
      setLastSync(new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      setDetectedBrandsCount(brandsData.length);
      setDetectedProjectsCount(projectsData.length);
      setFallbackModeActive(false);

      if (!silent) {
        triggerNotification("Koneksi berhasil terhubung dan tersambung dengan database!", "success");
      }
    } catch (err: any) {
      console.error("API link failed:", err);

      setConnectionStatus("failed");
      setConnectionError(err.message || "Network Error / Host Offline. Please verify details or check CORS.");
      setDetectedBrandsCount(0);
      setDetectedProjectsCount(0);
      
      // Update diagnostics on error to display the precise trace details for users (Requirement 5)
      setApiDiagnostics({
        apiUrl: finalApiUrl,
        healthUrl: healthUrl,
        status: err.message?.includes("Status: ") ? err.message.split("Status: ")[1] : "Fail / Offline",
        responseBody: err.message || "Network connection failure",
        timestamp: new Date().toLocaleTimeString("id-ID")
      });

      if (!silent) {
        triggerNotification(`Gagal terhubung ke API: ${err.message || "Masalah Jaringan"}`, "error");
      }
    } finally {
      setIsConnecting(false);
    }
  };

  // Load saved credentials on mount asynchronously
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedUrl = window.localStorage.getItem("alco_api_url");
      const savedKey = window.localStorage.getItem("alco_api_key");
      const savedFallback = window.localStorage.getItem("alco_fallback_mode_active") === "true";
      
      if (savedFallback) {
        setTimeout(() => {
          setConnectionStatus("disconnected");
        }, 0);
      } else if (savedUrl && savedKey) {
        // Run health check
        setTimeout(() => {
          executeActualHealthCheck(savedUrl, savedKey, false, true);
        }, 0);
      }
    }
  }, []);

  const handleManualConnect = () => {
    if (!apiBaseUrl.trim() || !apiToken.trim()) {
      triggerNotification("Peringatan: Alamat API (URL) dan Kunci Token wajib diisi.", "error");
      return;
    }
    executeActualHealthCheck(apiBaseUrl, apiToken);
  };

  const handlePasteChange = (text: string) => {
    setPasteJsonText(text);
    try {
      const trimmed = text.trim();
      if (trimmed.startsWith("{")) {
        const parsed = JSON.parse(trimmed);
        if (parsed.apiUrl || parsed.apiBaseUrl) {
          setApiBaseUrl(parsed.apiUrl || parsed.apiBaseUrl);
        }
        if (parsed.apiKey || parsed.apiToken) {
          setApiToken(parsed.apiKey || parsed.apiToken);
        }
      } else {
        const urlMatch = trimmed.match(/(?:apiUrl|url)["'\s:=]+([^;"'\s]+)/i);
        const keyMatch = trimmed.match(/(?:apiKey|key|token)["'\s:=]+([^;"'\s]+)/i);
        if (urlMatch) setApiBaseUrl(urlMatch[1]);
        if (keyMatch) setApiToken(keyMatch[1]);
      }
    } catch (_) {
      // Allow typing
    }
  };

  const handleImportJson = (jsonString: string) => {
    try {
      setJsonImportError(null);
      const parsed = JSON.parse(jsonString);
      
      if (!parsed.brandName) {
        throw new Error("Missing required field: 'brandName'");
      }
      if (!parsed.brandIdentity || !parsed.brandIdentity.voice || !parsed.brandIdentity.tone) {
        throw new Error("Missing or incomplete 'brandIdentity' (voice and tone needed)");
      }

      // Save imported context into local storage so dashboard page can consume it
      localStorage.setItem("alco_imported_dossier", JSON.stringify(parsed));
      localStorage.setItem("alco_fallback_mode_active", "true");
      localStorage.setItem("alco_api_url", "");
      localStorage.setItem("alco_api_key", "");

      setFallbackModeActive(true);
      setConnectionStatus("disconnected");
      triggerNotification("Berkas data Brand berhasil diimpor!", "success");
    } catch (err: any) {
      console.error(err);
      setJsonImportError(`Gagal memuat: ${err.message || "kesalahan format berkas"}`);
      triggerNotification("Format file JSON belum sesuai dengan data Brand.", "error");
    }
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    setJsonImportError(null);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type !== "application/json" && !file.name.endsWith(".json")) {
        setJsonImportError("Unsupported file type. Please upload a .json config file.");
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        handleImportJson(text);
      };
      reader.readAsText(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setJsonImportError(null);
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        handleImportJson(text);
      };
      reader.readAsText(file);
    }
  };

  const enableSandboxMode = () => {
    localStorage.setItem("alco_fallback_mode_active", "true");
    localStorage.setItem("alco_api_url", "");
    localStorage.setItem("alco_api_key", "");
    setFallbackModeActive(true);
    setConnectionStatus("disconnected");
    triggerNotification("Mode Sandbox (Offline) aktif. Anda bisa membuat konten kustom sekarang.", "info");
  };

  const resetConnection = () => {
    localStorage.removeItem("alco_api_url");
    localStorage.removeItem("alco_api_key");
    localStorage.setItem("alco_fallback_mode_active", "false");
    localStorage.removeItem("alco_imported_dossier");
    
    setApiBaseUrl("");
    setApiToken("");
    setConnectionStatus("disconnected");
    setFallbackModeActive(false);
    triggerNotification("Koneksi API berhasil dihapus sepenuhnya.");
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-start">
      {/* Toast Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className={`fixed top-4 right-4 z-50 px-5 py-3.5 rounded-xl shadow-xl border flex items-center gap-3 max-w-md ${
              notification.type === "error"
                ? "bg-red-50 border-red-200 text-red-800"
                : notification.type === "info"
                ? "bg-slate-900 border-slate-800 text-white"
                : "bg-emerald-50 border-emerald-200 text-emerald-800"
            }`}
          >
            <span className="text-xs font-mono font-bold">{notification.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Elegant Header */}
      <header className="bg-white border-b border-slate-200/80 px-6 py-4 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link 
              href="/"
              className="p-1.5 hover:bg-slate-100 rounded-lg transition mr-1 flex items-center gap-1.5 text-xs font-bold text-slate-650"
            >
              <ArrowLeft size={16} />
              <span>Kembali</span>
            </Link>
            <div className="h-6 w-px bg-slate-200 mx-2" />
            <div>
              <h1 className="text-sm font-black font-mono tracking-tight uppercase text-slate-900 flex items-center gap-1.5">
                <Sliders size={14} className="text-blue-600" />
                PENGATURAN API
              </h1>
              <p className="text-[10px] text-slate-400 font-mono">Halaman Pengaturan Sambungan</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs px-4 py-2 rounded-xl transition duration-150 flex items-center gap-1.5 shadow-sm font-bold"
            >
              <span>Pergi ke Dashboard</span>
              <ArrowRight size={13} />
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto px-4 py-8 flex-1 w-full space-y-8">
        
        {/* Intro */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500/10 text-blue-600 rounded-full text-[10px] font-mono font-extrabold uppercase tracking-widest border border-blue-500/20">
            <Radio size={12} className="animate-pulse" /> PORTAL KONEKSI
          </div>
          <h2 className="text-3xl font-black text-slate-900 font-sans tracking-tight uppercase">
            Sederhanakan Sambungan Jalur API
          </h2>
          <p className="text-xs text-slate-500 font-mono max-w-xl mx-auto leading-relaxed">
            Hubungkan dan sinkronkan Sistem Perencanaan Konten Anda dengan database utama. Setelah diatur di sini, perubahan Anda akan otomatis tersimpan dan terhubung langsung ke halaman utama.
          </p>
        </div>

        {/* Success Announcement Widget (If paired successfully) */}
        {(connectionStatus === "active" || fallbackModeActive) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`p-6 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-5 ${
              connectionStatus === "active" 
                ? "bg-emerald-50 border-emerald-250 text-emerald-900" 
                : "bg-amber-50 border-amber-250 text-amber-900"
            }`}
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-2xl ${connectionStatus === "active" ? "bg-emerald-500/15 text-emerald-600" : "bg-amber-500/15 text-amber-600"} shrink-0`}>
                <CheckCircle size={28} />
              </div>
              <div>
                <h3 className="text-sm font-bold uppercase font-mono tracking-tight">
                  {connectionStatus === "active" ? "SAMBUNGAN API AKTIF" : "MODE COBA-COBA (SANDBOX) AKTIF"}
                </h3>
                <p className="text-xs mt-1 leading-relaxed opacity-80 font-mono">
                  {connectionStatus === "active" 
                    ? `Berhasil terhubung ke server API di ${apiBaseUrl}. Seluruh data Brand Anda siap digunakan secara otomatis.`
                    : `Berjalan dalam mode coba-coba lokal. Anda bisa membuat rencana promosi secara offline tanpa perlu terhubung internet.`}
                </p>
                <div className="flex flex-wrap items-center gap-3 mt-3 font-mono text-[11px]">
                  {connectionStatus === "active" && (
                    <>
                      <span className="bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded text-emerald-800">
                        {detectedBrandsCount} Brand Terhubung
                      </span>
                      <span className="bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded text-emerald-800">
                        {detectedProjectsCount} Project Aktif
                      </span>
                    </>
                  )}
                  {fallbackModeActive && (
                    <span className="bg-amber-105 bg-amber-100 border border-amber-200 px-2.5 py-0.5 rounded text-amber-800">
                      Data Kustom Berhasil Dimuat
                    </span>
                  )}
                  <span className="opacity-65">Waktu Update: {lastSync === "Never" ? "Baru Saja Aktif" : lastSync}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 shrink-0 w-full md:w-auto">
              <button
                onClick={resetConnection}
                className="bg-white/80 hover:bg-white text-slate-800 border border-slate-200 px-4 py-2 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Hapus Sambungan
              </button>
              <Link
                href="/"
                className="bg-blue-600 hover:bg-blue-500 text-white px-5 py-2 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
              >
                <span>Halaman Utama</span>
                <ArrowRight size={13} />
              </Link>
            </div>
          </motion.div>
        )}

        {/* API Credentials Setup Card */}
        <div className="bg-slate-950 text-white rounded-2xl border border-slate-850 p-6 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-40 bg-gradient-to-br from-blue-500/10 to-transparent blur-3xl pointer-events-none" />

          {/* Card Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-850 pb-5 mb-5 font-mono">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${connectionStatus === "active" ? "bg-emerald-500/10 text-emerald-400" : connectionStatus === "failed" ? "bg-red-500/10 text-red-400" : "bg-blue-500/10 text-blue-400"}`}>
                <Radio className={isConnecting ? "animate-spin text-blue-400" : ""} size={20} />
              </div>
              <div>
                <h3 className="text-xs tracking-wider text-slate-500 font-bold uppercase">ALUR INTEGRASI API</h3>
                <h4 className="text-sm font-bold text-white tracking-tight mt-0.5 font-sans">Sambungan Data Mudah</h4>
              </div>
            </div>
            
            {/* Link Diagnostic Status Badge */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-500 uppercase font-semibold">STATUS:</span>
              <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase flex items-center gap-1.5 shadow-inner ${
                connectionStatus === "active"
                  ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                  : connectionStatus === "failed"
                  ? "bg-red-500/15 text-red-400 border border-red-500/30 animate-pulse"
                  : "bg-slate-900 text-slate-400 border border-slate-800"
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${
                  connectionStatus === "active" ? "bg-emerald-500"
                  : connectionStatus === "failed" ? "bg-red-500 animate-pulse"
                  : "bg-slate-500"
                }`} />
                {connectionStatus === "active" ? "Terhubung" : connectionStatus === "failed" ? "Gagal" : "Belum Terhubung"}
              </span>
            </div>
          </div>

          {/* Connection Error Banner */}
          {connectionStatus === "failed" && connectionError && (
            <div className="mb-6 p-4 bg-red-950/40 border border-red-500/30 rounded-xl text-red-200 text-xs font-mono space-y-2 animate-fadeIn">
              <div className="flex items-center gap-2 text-red-450 text-red-400 font-bold">
                <span className="text-sm">⚠️</span>
                <span>KONEKSI API GAGAL TERHUBUNG</span>
              </div>
              <p className="whitespace-pre-line leading-relaxed text-[11px] text-red-300">
                {connectionError}
              </p>
              <div className="pt-1.5 text-[10px] text-red-400 font-semibold">
                <span>Tips: Pastikan server target aktif dan alamat API yang dimasukkan sudah benar.</span>
              </div>
            </div>
          )}

          <div className="space-y-5">
            {/* Connection Package Info Banner */}
            <div className="flex items-start gap-3 bg-slate-900/50 p-4 rounded-xl border border-slate-850/40">
              <span className="text-xl">📥</span>
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-300 font-mono block">Masukkan Kunci Integrasi Anda</span>
                <span className="text-[10px] text-slate-400 leading-normal block">
                  Tempelkan format JSON konfigurasi atau masukkan alamat/kunci API Anda di bawah ini secara manual untuk memulai.
                </span>
              </div>
            </div>

            {/* Paste Token Area */}
            <div className="space-y-1.5">
              <label className="block text-xs uppercase font-mono text-slate-400 font-bold">
                Tempelkan Format JSON atau Token Akses
              </label>
              <textarea
                onChange={(e) => handlePasteChange(e.target.value)}
                value={pasteJsonText}
                placeholder={`{\n  "apiUrl": "https://alco-core.app/api",\n  "apiKey": "alco_xxxxx"\n}`}
                rows={3}
                className="w-full bg-slate-900 border border-slate-850 rounded-xl p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 tracking-tight"
              />
            </div>

            {/* Connection properties row */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              {/* Base URL */}
              <div className="md:col-span-5 space-y-1.5">
                <label className="block text-xs font-mono uppercase text-slate-400 font-semibold flex items-center gap-1">
                  <Globe size={11} className="text-blue-400" /> HALAMAN UTAMA API URL
                </label>
                <input
                  type="text"
                  value={apiBaseUrl}
                  onChange={(e) => {
                    setApiBaseUrl(e.target.value);
                    if (connectionStatus === "active") setConnectionStatus("disconnected");
                  }}
                  placeholder="Contoh: https://alco-core.app/api"
                  className="w-full bg-slate-900 border border-slate-850 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Security Key */}
              <div className="md:col-span-7 space-y-1.5">
                <label className="block text-xs font-mono uppercase text-slate-400 font-semibold flex items-center gap-1">
                  <Key size={11} className="text-blue-400" /> KUNCI OTENTIKASI API (x-api-key)
                </label>
                <input
                  type="password"
                  value={apiToken}
                  onChange={(e) => {
                    setApiToken(e.target.value);
                    if (connectionStatus === "active") setConnectionStatus("disconnected");
                  }}
                  placeholder="Ketik Kunci API di sini"
                  className="w-full bg-slate-900 border border-slate-850 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-900 flex justify-end">
              <button
                type="button"
                onClick={handleManualConnect}
                disabled={isConnecting}
                className="bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs uppercase tracking-tight py-2.5 px-6 rounded-xl transition duration-150 shadow-md font-bold disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
              >
                {isConnecting ? (
                  <>
                    <RefreshCcw size={12} className="animate-spin" /> Sedang Menghubungkan...
                  </>
                ) : (
                  <>
                    <Wifi size={13} /> HUBUNGKAN API SEKARANG
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Live API Diagnostics Logs Panel (Requirement 1, 2, 5) */}
        {apiDiagnostics && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white font-mono space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                <span>🔌 LIVE API DIAGNOSTICS BOARD</span>
              </div>
              <span className="text-[10px] text-slate-500">Timestamp: {apiDiagnostics.timestamp}</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 block tracking-wider">RESOLVED API URL</span>
                <span className="text-slate-200 block break-all font-semibold bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-850">
                  {apiDiagnostics.apiUrl || "(None)"}
                </span>
              </div>
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 block tracking-wider">PROBED HEALTH URL</span>
                <span className="text-slate-200 block break-all font-semibold bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-850">
                  {apiDiagnostics.healthUrl || "(None)"}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 text-xs">
              <div className="md:col-span-3 space-y-1">
                <span className="text-[10px] text-slate-400 block tracking-wider font-semibold">RESPONSE STATUS</span>
                <span className={`block font-bold text-center px-2.5 py-1.5 rounded-lg border ${
                  String(apiDiagnostics.status).startsWith("2")
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    : "bg-red-500/10 text-red-500 border-red-500/20"
                }`}>
                  {apiDiagnostics.status || "No status returned"}
                </span>
              </div>
              
              <div className="md:col-span-9 space-y-1">
                <span className="text-[10px] text-slate-400 block tracking-wider flex items-center justify-between">
                  <span>RESPONSE BODY REVEAL</span>
                  <span className="text-[9px] text-slate-500 font-normal">Payload</span>
                </span>
                <pre className="text-[11px] bg-slate-950 p-3 rounded-lg border border-slate-850 overflow-x-auto max-h-40 text-slate-300 whitespace-pre-wrap select-text leading-tight font-mono">
                  {apiDiagnostics.responseBody || "(Empty response)"}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* Unified Diagnostic Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm font-mono text-[11px]">
          <div className="space-y-1 border-r border-slate-150 pr-2">
            <span className="text-slate-400 block text-[9px] uppercase tracking-wide font-bold">API STATUS</span>
            <span className={`font-bold flex items-center gap-1.5 ${connectionStatus === "active" ? "text-emerald-700" : "text-slate-500"}`}>
              <Activity size={12} className="text-blue-500" /> {connectionStatus.toUpperCase()}
            </span>
          </div>
          <div className="space-y-1 border-r border-slate-150 pr-2 pl-2">
            <span className="text-slate-400 block text-[9px] uppercase tracking-wide font-bold">GATEWAY VER</span>
            <span className="text-slate-700 font-bold flex items-center gap-1.5">
              <Cpu size={12} className="text-blue-505 text-blue-500" /> {schemaVersion}
            </span>
          </div>
          <div className="space-y-1 border-r border-slate-150 pr-2 pl-2">
            <span className="text-slate-400 block text-[9px] uppercase tracking-wide font-bold">SYNCED DOSSIERS</span>
            <span className="text-slate-700 font-bold flex items-center gap-1.5">
              <Layers size={12} className="text-blue-500" /> {detectedBrandsCount} Brands
            </span>
          </div>
          <div className="space-y-1 pl-2">
            <span className="text-slate-400 block text-[9px] uppercase tracking-wide font-bold">PROJECT DESKS</span>
            <span className="text-slate-700 font-bold flex items-center gap-1.5">
              <ListChecks size={12} className="text-blue-500" /> {detectedProjectsCount} Active
            </span>
          </div>
        </div>

        {/* Diagnostic Failover Options (When connection is not active or user chose to inspect local config) */}
        <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 space-y-5 shadow-inner">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="text-slate-500 mt-0.5 shrink-0" size={16} />
            <div>
              <h4 className="text-xs uppercase font-mono font-bold text-slate-700">Mode Mandiri & Pilihan Offline Untuk Pemula</h4>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed font-mono">
                Belum punya server API atau kesulitan menghubungkannya? Jangan khawatir! Anda tetap bisa menggunakan aplikasi dengan dua cara mudah berikut ini.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Option A: Dossier Import Upload */}
            <div 
              className={`border border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center transition duration-150 bg-white ${
                isDraggingFile ? "border-blue-500/60 text-blue-800 bg-blue-500/5 animate-pulse" : "border-slate-200 text-slate-600 hover:border-slate-350"
              }`}
              onDragOver={(e) => { e.preventDefault(); setIsDraggingFile(true); }}
              onDragLeave={() => setIsDraggingFile(false)}
              onDrop={handleFileDrop}
            >
              <FileJson className="mb-2.5 text-slate-400 shrink-0" size={24} />
              <span className="text-xs font-semibold text-slate-800">Opsi A: Unggah Berkas JSON Brand</span>
              <span className="text-[10px] text-slate-500 font-mono mt-1">Tarik file ke sini atau pilih dari komputer Anda</span>
              
              <input
                type="file"
                id="page-file-json-selector"
                className="hidden"
                accept=".json"
                onChange={handleFileSelect}
              />
              <label
                htmlFor="page-file-json-selector"
                className="mt-4 bg-slate-900 hover:bg-slate-800 px-4 py-1.5 rounded-lg text-[10px] font-mono text-white uppercase font-bold cursor-pointer transition select-none tracking-tight"
              >
                Pilih Berkas
              </label>

              {jsonImportError && (
                <p className="text-[10px] text-red-550 text-red-600 mt-2 font-mono text-center leading-normal">{jsonImportError}</p>
              )}
            </div>

            {/* Option B: Manual Input Sandbox */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" /> Opsi B: Mode Sandbox (Tanpa internet)
                </span>
                <p className="text-[10px] text-slate-500 font-mono mt-2 leading-relaxed">
                  Cobalah seluruh fitur pembuat rencana promosi menggunakan template contoh bawaan yang aman tanpa perlu mengatur server API sama sekali.
                </p>
              </div>
              
              <button
                type="button"
                onClick={enableSandboxMode}
                className="mt-6 w-full bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 py-2 rounded-xl text-[10px] font-mono uppercase font-bold tracking-tight transition cursor-pointer"
              >
                + Mulai Mode Sandbox Offline
              </button>
            </div>
          </div>
        </div>

      </main>

      {/* Elegant Footer */}
      <footer className="bg-white border-t border-slate-200/80 px-6 py-6 font-mono text-[10px] text-slate-400 mt-12 text-center shadow-inner">
        <p className="max-w-lg mx-auto">
          ALCO OS Core Integrity Bridge Center • Formulated securely on Sandboxed Host Operations. All stored keys persist locally in client browser buffers.
        </p>
      </footer>
    </div>
  );
}
